"""Fixed-accuracy long horizons (Section 9.2 and Figure 2b).

(a) The constants for the model kernel are computed by p1_constants.py.
(b) Flat spectrum (five random realisations per case; median reported, 2e4 = no failure up to the end) on [0,1] (gamma(t) = sin t / t, gamma(0) = 1): first failure time of the uniform midpoint grid
    and of a jittered grid (one random frequency per equal-mass cell), G modes of weight 1/G.
Writes data/long_horizon.json.
"""
import json
import numpy as np

out = {}


def fail_time(om, d, Tmax=2e4, h=0.05):
    t0 = 0.0
    while t0 < Tmax:
        t = np.arange(t0, min(t0 + 2000, Tmax), h)
        gG = np.cos(np.outer(t, om)).mean(axis=1)
        ex = np.sinc(t / np.pi)
        bad = np.nonzero(np.abs(gG - ex) > d)[0]
        if len(bad):
            return float(t[bad[0]])
        t0 = t[-1] + h
    return None   # no failure up to Tmax


rows = []
for G in (250, 500, 1000):
    for d in (0.02, 0.05, 0.1):
        uni = (np.arange(G) + 0.5) / G
        jt = [fail_time((np.arange(G) + np.random.default_rng(seed * 1000 + G).random(G)) / G, d) for seed in range(1, 6)]
        fin = [x for x in jt if x is not None]
        rows.append(dict(G=G, delta=d, uniform=fail_time(uni, d), jittered_seeds=jt,
                         jittered=(float(np.median([x if x is not None else 2e4 for x in jt]))), n_no_failure=len(jt) - len(fin), G_delta2=G * d * d))
        print(rows[-1], flush=True)
out['flat'] = rows
json.dump(out, open('data/long_horizon.json', 'w'), indent=1)
