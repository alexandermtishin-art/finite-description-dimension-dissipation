import json, os, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix','font.size':10,
  'axes.linewidth':0.8,'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True})
BLUE,ORANGE,AQUA,INK='#2a78d6','#eb6834','#1baf7a','#222222'
def load(target,cls):
    d={}
    for fn in [f'part1_res_{target}_{cls}.json',f'res2_{target}_{cls}.json']:
        if os.path.exists(fn):
            for k,v in json.load(open(fn)).items():
                k=int(k)
                if k not in d or v['err_all']<d[k]['err_all']: d[k]=v
    G=sorted(d); return np.array(G),np.array([d[g]['err_all'] for g in G])
lb=json.load(open('lb.json')); cons=json.load(open('cons.json'))
fig,axs=plt.subplots(1,2,figsize=(7.0,3.0),sharey=True)
for ax,target,title in zip(axs,['flat','debye'],[r'(a) flat band, $\rho=\mathbf{1}_{[0,\Omega]}$',r'(b) Debye, $\rho\propto\omega^{3}$ on $[0,\Omega]$']):
    Gl=np.array(sorted(int(k) for k in lb[target])); dl=np.array([lb[target][str(g)] for g in Gl])
    ax.fill_between(Gl,1e-6,dl,color='#e6e6e3',lw=0)
    ax.plot(Gl,dl,color=INK,lw=1.4,label='necessary bound, Eq. (6)')
    G,e=load(target,'pos'); ax.plot(G,e,'o-',color=BLUE,lw=1.6,ms=5,label='optimized positive Lorentzian')
    G,e=load(target,'sgn'); ax.plot(G,e,'s-',color=ORANGE,lw=1.6,ms=5,label='optimized, signed weights and phases')
    if target=='flat':
        Gc=np.array(sorted(int(k) for k in cons)); ec=np.array([cons[str(g)]['actual'] for g in Gc])
        ax.plot(Gc,ec,'^--',color=AQUA,lw=1.2,ms=5,label='explicit construction, Eq. (11)')
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(0.8,300); ax.set_ylim(1e-5,0.3)
    ax.set_xlabel(r'number of lines $G$'); ax.set_title(title,fontsize=10,loc='left')
    ax.text(30,2.2e-5,'excluded for positive\nLorentzian descriptions',fontsize=8,color='#555555',ha='center')
axs[0].set_ylabel(r'all-time error $\varepsilon=\sup_t|h_G-\gamma|/A_0$')
h,l=axs[0].get_legend_handles_labels()
fig.legend(h,l,loc='lower center',ncol=2,frameon=False,fontsize=8.5,bbox_to_anchor=(0.5,-0.02))
fig.tight_layout(rect=(0,0.13,1,1))
fig.savefig('Fig1_main.pdf'); fig.savefig('Fig1_main.png',dpi=300)
