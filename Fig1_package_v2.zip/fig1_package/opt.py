import numpy as np, sys, json, time
from scipy.optimize import minimize
# ---------- targets (Omega = 1) ----------
def gamma_flat(t): return np.sinc(t/np.pi)                     # rho = 1 on [0,1], A0 = 1
def gamma_debye(t):                                            # rho = 4 w^3 on [0,1], A0 = 1
    t=np.asarray(t,float); out=np.empty_like(t)
    s=np.abs(t)<1.0
    x,w=np.polynomial.legendre.leggauss(60); x=(x+1)/2; w=w/2
    out[s]=(4*x**3*w*np.cos(np.outer(t[s],x))).sum(1)
    u=np.abs(t[~s]); S,C=np.sin(u),np.cos(u)
    F=S/u+3*C/u**2-6*S/u**3-6*C/u**4+6/u**4
    out[~s]=4*F
    return out
TARGETS={'flat':gamma_flat,'debye':gamma_debye}
def grid(T):
    return np.concatenate([np.arange(0,80,0.02),np.arange(80,T,0.08)])
# ---------- model: sum W cos(w t + phi) e^{-G t} ----------
def model(x,G,cls,t):
    if cls=='pos':
        W=np.exp(x[:G]); w=x[G:2*G]; Ga=np.exp(x[2*G:3*G]); ph=np.zeros(G)
    else:
        W=x[:G]; w=x[G:2*G]; Ga=np.exp(x[2*G:3*G]); ph=x[3*G:4*G]
    E=np.exp(-np.outer(Ga,t)); arg=np.outer(w,t)+ph[:,None]
    Cc,Ss=np.cos(arg),np.sin(arg)
    h=(W[:,None]*E*Cc).sum(0)
    return h,(W,w,Ga,ph,E,Cc,Ss)
def obj(x,G,cls,t,g,p):
    h,(W,w,Ga,ph,E,Cc,Ss)=model(x,G,cls,t)
    e=h-g; m=np.max(np.abs(e))+1e-300; r=e/m
    M=np.mean(np.abs(r)**p); f=m*M**(1/p)
    c=M**(1/p-1)*np.abs(r)**(p-1)*np.sign(r)/len(t)   # df/de
    dW=(E*Cc)@c; dw=-(W[:,None]*E*Ss*t)@c; dGa=-(W[:,None]*E*Cc*t)@c
    if cls=='pos':
        gr=np.concatenate([dW*W,dw,dGa*Ga])
    else:
        dph=-(W[:,None]*E*Ss)@c
        gr=np.concatenate([dW,dw,dGa*Ga,dph])
    return f,gr
def supall(x,G,cls,gfun):
    # all-time check: dense grid to well beyond 30/min width
    _,(W,w,Ga,ph,*_)=model(x,G,cls,np.array([0.0]))
    Tend=max(4000,40/Ga.min())
    Tend=min(Tend,2e5)
    t=np.concatenate([np.arange(0,80,0.01),np.arange(80,Tend,0.05)])
    out=0
    for k in range(0,len(t),200000):
        tt=t[k:k+200000]; h,_=model(x,G,cls,tt); out=max(out,np.max(np.abs(h-gfun(tt))))
    return out,Ga.min(),Tend
def fit(target,cls,G,T,starts,seed=0,warm=None):
    gfun=TARGETS[target]; t=grid(T); g=gfun(t)
    rng=np.random.default_rng(seed); best=None
    inits=[]
    if warm is not None: inits.append(warm)
    for s in range(starts):
        A=1.0
        W0=np.full(G,A/G)*(1+0.2*rng.random(G)); w0=(np.arange(G)+0.5)/G+0.3/G*rng.normal(size=G)
        Ga0=np.full(G,1.0/G)*(0.2+rng.random())
        if cls=='pos': x0=np.concatenate([np.log(W0),w0,np.log(Ga0)])
        else: x0=np.concatenate([W0,w0,np.log(Ga0),0.1*rng.normal(size=G)])
        inits.append(x0)
    for x0 in inits:
        x=x0
        for p in [8,32,128,512]:
            r=minimize(obj,x,args=(G,cls,t,g,p),jac=True,method='L-BFGS-B',options={'maxiter':4000})
            x=r.x
        e=np.max(np.abs(model(x,G,cls,t)[0]-g))
        if best is None or e<best[0]: best=(e,x)
    return best
if __name__=='__main__':
    target,cls=sys.argv[1],sys.argv[2]; Gs=[int(v) for v in sys.argv[3].split(',')]; starts=int(sys.argv[4])
    res={}
    for G in Gs:
        t0=time.time(); e,x=fit(target,cls,G,4000,starts,seed=G)
        ea,gmin,Tend=supall(x,G,cls,TARGETS[target])
        res[G]=dict(err_grid=e,err_all=ea,min_width=gmin,Tcheck=Tend,x=x.tolist())
        print(f"{target} {cls} G={G:3d} err_grid={e:.5f} err_alltime={ea:.5f} G*err={G*ea:.3f} minGa={gmin:.2e} [{time.time()-t0:.0f}s]",flush=True)
        json.dump(res,open(f"res_{target}_{cls}.json","w"))
