import numpy as np, json
from scipy.optimize import brentq, minimize_scalar
from scipy.integrate import quad
# targets: flat rho=1 on [0,1]; debye rho=4w^3 on [0,1]; A0=1, Omega=1
Q2={'flat':np.pi*1.0,'debye':np.pi*quad(lambda w:(4*w**3)**2,0,1)[0]}
def G6(d,R,Q2,A0=1,Om=1):
    C=1+np.sqrt((R+Om)/(R-Om)); b=2*R*C; a=A0-(1+2*C)*d
    if a<=0: return 0.0
    return a**3/(2*((b*Q2*d)**(1/3)+(a*d*d)**(1/3))**3)
def Gbound(d,Q2):  # best R
    r=minimize_scalar(lambda R:-G6(d,R,Q2),bounds=(1.0001,20),method='bounded')
    return -r.fun
def dlb(G,Q2):     # smallest delta compatible with G lines: Gbound(d)<=G
    f=lambda d: Gbound(d,Q2)-G
    lo,hi=1e-8,0.3
    if f(hi)>0: return hi
    return brentq(f,lo,hi)
out={}
for k in Q2:
    out[k]={G:dlb(G,Q2[k]) for G in [1,2,4,8,16,32,64,128,256,512,1024]}
    print(k,"Q2=%.4f"%Q2[k],{G:"%.2e"%v for G,v in out[k].items()})
json.dump(out,open('lb.json','w'))
# construction (11) flat band: guaranteed delta and actual all-time error
cons={}
for d in [0.3,0.2,0.1,0.05,0.03]:
    G=int(np.ceil(2/(np.pi*d)*np.log(2/d))); w=(np.arange(1,G+1)-0.5)/G
    t=np.concatenate([np.arange(0,80,0.01),np.arange(80,60/d,0.05)])
    h=np.zeros_like(t)
    for wj in w: h+=np.cos(wj*t)
    h*=np.exp(-d/2*t)/G
    e=np.max(abs(h-np.sinc(t/np.pi))); cons[G]=dict(delta=d,actual=e)
    print(f"construction delta={d}: G={G} actual={e:.4f}")
json.dump(cons,open('cons.json','w'))
