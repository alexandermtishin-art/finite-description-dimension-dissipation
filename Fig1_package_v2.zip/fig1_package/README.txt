Figure 1 (JCP version): all-time error of G-line descriptions vs necessary bound.
opt.py / opt2.py  minimax fits (smoothed max-norm, analytic gradient, L-BFGS-B), all-time check to max(4000, 40/Gamma_min)
                  usage: python3 opt2.py <flat|debye> <pos|sgn> <G list> <starts>
bounds.py         Eq. (6) optimized over R -> lb.json; construction (11) actual errors -> cons.json
fig.py            plots Fig1_main.pdf/png from part1_res_*.json (first campaign, fine grid) and res2_*.json (second campaign)
Targets: flat rho=1 on [0,1]; Debye rho=4 w^3 on [0,1]; A0=Omega=1.
Fitted values are local optima, i.e. upper bounds on the true minimal error.
