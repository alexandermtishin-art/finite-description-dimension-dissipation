import numpy as np, sys, json
sys.path.insert(0,'.')
from common import gamma
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
def Mk_float(N,h):
    k=np.arange(N+1,dtype=float)
    def I(a):
        a=np.asarray(a,float); out=np.empty_like(a); s=np.abs(a)<1e-3
        out[s]=0.5-a[s]**2/8+a[s]**4/144
        b=a[~s]; out[~s]=(b*np.sin(b)+np.cos(b)-1)/b**2; return out
    kk=np.arange(N); return 8/h*(I(kk*h)-(I((kk+1)*h)+I(np.abs(kk-1)*h))/2)
def rank_bound(T,d,h=0.5):
    N=int(np.ceil(T/h)); h=T/N; m=Mk_float(N,h)
    from scipy.linalg import toeplitz, eigvalsh
    lam=np.sort(eigvalsh(toeplitz(m)))[::-1]
    tail=np.sum(lam**2)-np.concatenate([[0],np.cumsum(lam**2)])
    r=np.where(tail>(T*d)**2)[0]; return (r.max()//2+1) if len(r) else 0
def fejer(T,d):
    t=np.linspace(0,T,int(T*100)+1); g=gamma(t); m2=2/T*np.trapezoid((1-t/T)*g**2,t)
    return (1-d)**2/(2*(np.sqrt(m2)+d)**2)
Ts=np.geomspace(3,1500,16)
res={'T':Ts.tolist()}
for d in [0.02,0.005,0.001]:
    res[str(d)]=[int(rank_bound(T,d)) for T in Ts]
res['fejer']=[fejer(T,0.02) for T in Ts]
json.dump(res,open('fig3a.json','w')); print(res)
