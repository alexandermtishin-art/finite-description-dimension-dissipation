import numpy as np, sys, time, json
from flint import arb, arb_mat, ctx
ctx.prec=128
def I(a):  # int_0^1 w cos(a w) dw
    if a==0: return arb(1)/2
    return (a*a.sin()+a.cos()-1)/(a*a)
def Mk(k,h):
    hh=arb(h)
    return 8/hh*(I(k*hh)-(I((k+1)*hh)+I(abs(k-1)*hh))/2)
def certify(T,N,deltas=(0.02,0.005,0.001)):
    h=T/N
    while h*N>T: h=np.nextafter(h,0)
    t0=time.time()
    m=[Mk(k,h) for k in range(N)]
    mid=np.array([float(x.mid()) for x in m])
    # rigorous squared Frobenius norm
    F2=m[0]**2*N
    for k in range(1,N): F2+=2*(N-k)*m[k]**2
    Mf=np.array([[mid[abs(i-j)] for j in range(N)] for i in range(N)])
    lam,Q=np.linalg.eigh(Mf); idx=np.argsort(lam)[::-1]; lam=lam[idx]; Q=Q[:,idx]
    # rigorous residuals
    Ma=arb_mat([[m[abs(i-j)] for j in range(N)] for i in range(N)])
    Qa=arb_mat(Q.tolist())
    R=Ma*Qa-Qa*arb_mat([[arb(lam[j]) if i==j else arb(0) for j in range(N)] for i in range(N)])
    E=Qa.transpose()*Qa-arb_mat([[1 if i==j else 0 for j in range(N)] for i in range(N)])
    def fro(A):
        s=arb(0)
        for i in range(A.nrows()):
            for j in range(A.ncols()):
                s+=A[i,j]**2
        return s.sqrt()
    eta=float(fro(E).upper()); Rn=float(fro(R).upper())
    lmax=float(max(abs(lam)))
    Fn=np.sqrt(1+eta)*Rn+eta*lmax
    xi=(1-eta)**-0.5-1
    rho=(1+xi)**2*Fn+lmax*xi*(2+xi)
    rho=rho*(1+1e-12)+1e-300
    out={}
    up=np.cumsum(np.maximum(lam+rho,0)**2)
    F2lo=float(F2.lower())
    for delta in deltas:
        thr=(T*delta)**2
        tail_lo=F2lo-np.concatenate([[0],up])
        r_fail=np.where(tail_lo>thr*(1+1e-9))[0]
        rmax=int(r_fail.max()) if len(r_fail) else -1
        # rigorous re-check of the decisive rank in Arb
        if rmax>=0:
            ssum=arb(0)
            for n in range(rmax): ssum+=(arb(float(lam[n]))+arb(rho))**2
            ok=(F2-ssum-arb(T)**2*arb(delta)**2)>0
            assert ok, ('arb check failed',delta,rmax)
        out[str(delta)]=rmax//2+1
    return dict(T=T,N=N,h=h,rho=rho,eta=eta,Gcert=out,secs=round(time.time()-t0,1))
if __name__=='__main__':
    T=float(sys.argv[1]); N=int(sys.argv[2])
    print(json.dumps(certify(T,N)))
