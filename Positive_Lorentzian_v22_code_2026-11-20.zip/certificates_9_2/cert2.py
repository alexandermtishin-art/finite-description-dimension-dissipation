import sys, time, json
from flint import arb, fmpq, ctx
ctx.prec=80
G=int(sys.argv[1]); Gam=fmpq(int(sys.argv[2]),10000)   # Gamma = n/10000 exactly
T1=int(sys.argv[3]); step=fmpq(1,50)                    # grid step 0.02 exact
W=[arb(fmpq((j+1)**4-j**4, G**4)) for j in range(G)]
w=[arb(fmpq(2*j+1,2*G)) for j in range(G)]
GA=arb(Gam)
def gam(t):
    if t==0: return arb(1)
    if t<1:
        # series of 4*int_0^1 w^3 cos(wt): sum (-1)^k t^{2k} 4/((2k)!(2k+4)), rigorous tail bound
        s=arb(0); term=arb(1); k=0; tt=arb(t)
        f=arb(1)
        while True:
            c=4/((arb(2*k+4))*f)*tt**(2*k)*(-1)**k
            s+=c; k+=1; f*= (2*k-1)*(2*k)
            if k>30: break
        return s+arb(0,1e-30)
    u=arb(t); S=u.sin(); C=u.cos()
    return 4*(S/u+3*C/u**2-6*S/u**3-6*C/u**4+6/u**4)
t0=time.time(); emax=arb(0); n=int(T1/step)
for k in range(n+1):
    t=step*k; ta=arb(t)
    f=arb(0)
    for a,b in zip(W,w): f+=a*(b*ta).cos()
    e=abs(f*(-GA*ta).exp()-gam(t))
    if e.upper()>emax.upper(): emax=arb(e.upper())
M2=(GA+1)**2+arb(2)/3
interp=M2*arb(step)**2/8
u=arb(T1)
tail=(-GA*u).exp()+4*(1/u+3/u**2+6/u**3+12/u**4)
bound_grid=emax+interp
total=max(float(bound_grid.upper()),float(tail.upper()))
print(json.dumps(dict(G=G,Gamma=str(Gam),T1=T1,grid_max=float(emax.upper()),interp=float(interp.upper()),tail=float(tail.upper()),certified=total,secs=round(time.time()-t0))))
