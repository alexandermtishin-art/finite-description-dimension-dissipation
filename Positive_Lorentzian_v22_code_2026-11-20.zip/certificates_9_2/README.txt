Certificates for Sec. 9.2 (acoustic-phonon density rho = 4 w^3 on [0,1], A0 = 1, delta = 0.02)
common.py   gamma(t) closed form, uniform midpoint grid with exact cell masses
cert1b.py   Table 1 and Table S1 certified (three tolerances, final comparison in Arb); cert1.py: earlier single-tolerance version.
            Table 1 certified integer lower bounds:  python3 cert1.py T N
            (compression on N cells of length T/N <= 0.5; Arb entries; float eigh + Arb residual
             and orthogonality bounds + Weyl -> eigenvalue enclosure; exact Frobenius norm)
            runs used: 7.65 32 | 29.58 60,120,240 | 95.59 192,384 | 265.27 531,1061 | 642.34 1285 | 1430.88 2862
cert2.py    Table 2 all-time certificates:  python3 cert2.py G n T1   (Gamma = n/10000)
            runs used: 128 51 2000 | 192 39 2000 | 256 30 2000  -> t2_*.json
fig3a.py    floating-point rank and Fejer curves for Fig. 3(a) -> fig3a.json ; Fig3_new.png
Requires python-flint (Arb) >= 0.9.
