import numpy as np
def gamma(t):
    t=np.asarray(t,float); out=np.empty_like(t); s=np.abs(t)<1.0
    x,w=np.polynomial.legendre.leggauss(60); x=(x+1)/2; w=w/2
    out[s]=(4*x**3*w*np.cos(np.outer(t[s],x))).sum(1)
    u=np.abs(t[~s]); S,C=np.sin(u),np.cos(u)
    out[~s]=4*(S/u+3*C/u**2-6*S/u**3-6*C/u**4+6/u**4); return out
def grid(G):  # uniform midpoints on [0,1], exact cell masses of rho=4w^3
    e=np.arange(G+1)/G; W=e[1:]**4-e[:-1]**4; w=(np.arange(G)+0.5)/G; return W,w
def fG(t,G,Gam=0.0):
    W,w=grid(G); out=np.zeros_like(t)
    for a,b in zip(W,w): out+=a*np.cos(b*t)
    return out*np.exp(-Gam*np.abs(t))
