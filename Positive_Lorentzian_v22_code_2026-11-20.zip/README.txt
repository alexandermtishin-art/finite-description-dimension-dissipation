Accuracy barriers for positive Lorentzian bath representations
Code and data for manuscript version v22 (J. Chem. Phys. submission), 20.11.2026.

fig2/               Figure 2 (a)-(d) (Sec. 9.1): optimized fits, necessary bounds (Eq. (4), Corollary 2),
                    construction (11), response-function example (Sec. 9.1). See fig2/README.txt.
certificates_9_2/   Sec. 9.2, Tables 1-2, Table S1 and Fig. 3(a): Arb certificates for rho = 4 w^3.
                    See certificates_9_2/README.txt. Requires python-flint >= 0.9.
