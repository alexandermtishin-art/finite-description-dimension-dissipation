import numpy as np, json
from scipy.optimize import minimize, brentq
A0=1.0; Q2=np.pi/4
tau=lambda W:(1+W)*np.exp(-W)          # tail mass of rho = w e^{-w}
def Gfin(d,W,R):
    C=1+np.sqrt((R+W)/(R-W)); b=2*R*C; t=tau(W)
    dt=d+t/C; a=A0-(1+2*C)*d-2*t
    if a<=0: return 0.0
    return a**3/(2*((b*Q2*dt)**(1/3)+(a*d*d)**(1/3))**3)
def Gbest(d):
    best=0
    for W in np.linspace(0.5,40,400):
        for r in [1.2,1.414,1.8,2.5]:
            best=max(best,Gfin(d,W,r*W))
    return best
def dlb(G):
    f=lambda ld: Gbest(np.exp(ld))-G
    lo,hi=np.log(1e-9),np.log(0.2)
    if f(hi)>0: return 0.2
    return float(np.exp(brentq(f,lo,hi,xtol=1e-3)))
out={G:dlb(G) for G in [1,2,4,8,16,32,64,128,256,512,1024]}
print({G:f"{v:.2e}" for G,v in out.items()})
# asymptotic check: delta * Omega_delta * G -> A0^3/(25 Q2)?
for G,d in out.items():
    Wd=brentq(lambda W:tau(W)-d,0,200)
    print(G, f"delta*Omega_d*G={d*Wd*G:.4f}", "target", A0**3/(25*Q2))
json.dump(out,open('lb_ohm.json','w'))
