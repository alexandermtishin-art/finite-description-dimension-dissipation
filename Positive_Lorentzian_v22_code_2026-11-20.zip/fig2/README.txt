Figure 2 of manuscript v22 (was Figure 1 in v14-v19).
Figure 1 (JCP version): all-time error of G-line descriptions vs necessary bound.
opt.py / opt2.py  minimax fits (smoothed max-norm, analytic gradient, L-BFGS-B), all-time check to max(4000, 40/Gamma_min)
                  usage: python3 opt2.py <flat|debye> <pos|sgn> <G list> <starts>
bounds.py         Eq. (4) optimized over R -> lb.json; construction (9) actual errors -> cons.json
Targets: flat rho=1 on [0,1]; Debye rho=4 w^3 on [0,1]; A0=Omega=1.
Fitted values are local optima, i.e. upper bounds on the true minimal error.

v2 (17.11.2026): 2x2 figure.
tailbound.py   Corollary 2 finite bound for rho = w e^{-w} (Ohmic, exponential cutoff) -> lb_ohm.json
dyn.py         response function of a harmonic mode in the Debye bath (Volterra, dt=0.02, T=300):
               python3 dyn.py debye 0.1 0.5  -> dyn_debye.json  (kappa=0.1, omega0=0.5)
fig4.py        builds Fig1_main_v2.pdf/png
