import json, os, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix','font.size':10,
  'axes.linewidth':0.8,'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True})
BLUE,ORANGE,AQUA,INK='#2a78d6','#eb6834','#1baf7a','#222222'
def load(target,cls):
    d={}
    for fn in [f'part1_res_{target}_{cls}.json',f'res2_{target}_{cls}.json']:
        if os.path.exists(fn):
            for k,v in json.load(open(fn)).items():
                k=int(k)
                if k not in d or v['err_all']<d[k]['err_all']: d[k]=v
    G=sorted(d); return np.array(G),np.array([d[g]['err_all'] for g in G])
lb=json.load(open('lb.json')); lbo=json.load(open('lb_ohm.json')); cons=json.load(open('cons.json'))
fig,axs=plt.subplots(2,2,figsize=(7.0,5.6))
panels=[('flat',r'(a) flat band, $\rho=\mathbf{1}_{[0,\Omega]}$',lb['flat']),
        ('debye',r'(b) acoustic phonons, $\rho\propto\omega^{3}$ on $[0,\Omega]$',lb['debye']),
        ('ohm',r'(c) Ohmic, $\rho\propto\omega\,e^{-\omega/\omega_c}$',lbo)]
for ax,(target,title,L) in zip(axs.flat[:3],panels):
    Gl=np.array(sorted(int(k) for k in L)); dl=np.array([L[str(g)] for g in Gl])
    ax.fill_between(Gl,1e-6,dl,color='#e6e6e3',lw=0)
    ax.plot(Gl,dl,color=INK,lw=1.4,label='necessary bound, Eq. (4) / Corollary 2' if target=='flat' else None)
    G,e=load(target,'pos'); ax.plot(G,e,'o-',color=BLUE,lw=1.6,ms=4.5,label='optimized positive Lorentzian' if target=='flat' else None)
    G,e=load(target,'sgn'); ax.plot(G,e,'s-',color=ORANGE,lw=1.6,ms=4.5,label='optimized, signed weights and phases' if target=='flat' else None)
    if target=='flat':
        Gc=np.array(sorted(int(k) for k in cons)); ec=np.array([cons[str(g)]['actual'] for g in Gc])
        ax.plot(Gc,ec,'^--',color=AQUA,lw=1.2,ms=4.5,label='explicit construction, Eq. (9)')
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(0.8,300); ax.set_ylim(1e-6,0.3)
    ax.set_title(title,fontsize=10,loc='left')
    ax.text(25,3e-6,'excluded for positive\nLorentzian lines only',fontsize=7.5,color='#555555',ha='center')
    ax.set_ylabel(r'all-time error $\sup_t|h_G-\gamma|/A_0$',fontsize=9)
    ax.set_xlabel(r'number of lines $G$')
dyn=json.load(open('dyn_debye.json')); ax=axs[1,1]
for cls,c,m,lab in [('pos',BLUE,'o','positive Lorentzian'),('sgn',ORANGE,'s','signed weights and phases')]:
    G=np.array(sorted(int(k) for k in dyn[cls])); e=np.array([dyn[cls][str(g)]['resp_err'] for g in G])
    ax.plot(G,e,m+'-',color=c,lw=1.6,ms=4.5)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(0.8,300); ax.set_ylim(1e-3,1)
ax.set_title(r'(d) response $\chi(t)$ of a mode in bath (b)',fontsize=10,loc='left')
ax.set_ylabel(r'response error $\max_t|\chi_G-\chi|/\max_t|\chi|$',fontsize=9); ax.set_xlabel(r'number of lines $G$')
h,l=axs[0,0].get_legend_handles_labels()
fig.legend(h,l,loc='lower center',ncol=2,frameon=False,fontsize=8.5,bbox_to_anchor=(0.5,-0.01))
fig.tight_layout(rect=(0,0.07,1,1))
fig.savefig('Fig1_main_v2.pdf'); fig.savefig('Fig1_main_v2.png',dpi=300)
