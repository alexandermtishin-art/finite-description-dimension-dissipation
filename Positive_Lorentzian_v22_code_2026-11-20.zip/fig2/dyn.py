import numpy as np, json, sys
sys.path.insert(0,'.')
from opt2 import TARGETS, model
def response(K, w0, dt, N):
    # x'' + w0^2 x + int_0^t K(t-s) x'(s) ds = 0, x(0)=0, x'(0)=1 ; trapezoid, implicit in v_n
    x=np.zeros(N); v=np.zeros(N); a=np.zeros(N); v[0]=1.0
    a[0]=-w0**2*x[0]
    for n in range(1,N):
        S=dt*(np.dot(K[n-1:0:-1],v[1:n]) + 0.5*K[n]*v[0])
        rhs=v[n-1]+0.5*dt*a[n-1]+0.5*dt*(-w0**2*(x[n-1]+0.5*dt*v[n-1])-S)
        v[n]=rhs/(1+0.5*dt*(0.5*dt*w0**2+0.5*dt*K[0]))
        x[n]=x[n-1]+0.5*dt*(v[n-1]+v[n])
        a[n]=-w0**2*x[n]-S-0.5*dt*K[0]*v[n]
    return x
if __name__=='__main__':
    target=sys.argv[1]; kappa=float(sys.argv[2]); w0=float(sys.argv[3])
    T=300.0; dt=0.02; N=int(T/dt)+1; t=np.arange(N)*dt
    g=TARGETS[target](t)
    ref=response(kappa*g,w0,dt,N); scale=np.max(abs(ref))
    out={'ref_max':scale,'pos':{},'sgn':{}}
    import os
    for cls in ['pos','sgn']:
        d={}
        for fn in [f'part1_res_{target}_{cls}.json',f'res2_{target}_{cls}.json']:
            if os.path.exists(fn):
                for k,vv in json.load(open(fn)).items():
                    k=int(k)
                    if k not in d or vv['err_all']<d[k]['err_all']: d[k]=vv
        for G in sorted(d):
            x=np.array(d[G]['x']); h,_=model(x,G,cls,t)
            r=response(kappa*h,w0,dt,N)
            e=np.max(abs(r-ref))/scale
            grow=np.max(abs(r[-2000:]))/scale
            out[cls][G]=dict(kernel_err=d[G]['err_all'],resp_err=float(e),late_amp=float(grow))
            print(target,cls,G,f"kernel {d[G]['err_all']:.2e}  response {e:.2e}  late|x|/max {grow:.2e}",flush=True)
    print("ref late amp", np.max(abs(ref[-2000:]))/scale)
    json.dump(out,open(f'dyn_{target}.json','w'))
