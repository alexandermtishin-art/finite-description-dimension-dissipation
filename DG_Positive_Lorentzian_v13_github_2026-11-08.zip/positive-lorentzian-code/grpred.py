"""Test of the memory-time criterion for the collective precession reduction.
Full reference: N=512 nodes.  From each eligible turning point, group into G contiguous blocks,
evolve the reduced equations, and compare with the full trajectory over a long horizon.
Prediction: the grouped prediction fails after a time of order tau_G set by the grouped memory kernel.
"""
import sys, json
import numpy as np
from scipy.integrate import solve_ivp
from prot import run, approaches
from model import V, Vp, qt, qb, m0, g

NREF, K, H = 512, 8.0, 60.0
Gs = [8, 16, 32, 64, 128]
vss=[]


def group(k, W, s, G):
    B = np.array_split(np.arange(len(k)), G)
    WB = np.array([W[b].sum() for b in B])
    kB = np.array([(W[b] * k[b]).sum() for b in B]) / WB
    SB = np.stack([(W[b] * s[:, b]).sum(axis=1) for b in B], axis=1) / WB
    return kB, WB, SB


def red_rhs(kB, WB, Z):
    G = len(kB)
    def f(t, y):
        q, v = y[0], y[1]; S = y[2:].reshape(3, G); M = m0 + g * q; E = np.hypot(kB, M)
        F = g * np.sum(WB * (S[2] + M / E)); a = -(Vp(q) + F) / Z
        return np.concatenate([[v, a], (2 * np.stack([-M * S[1], M * S[0] - kB * S[2], kB * S[1]])).ravel()])
    return f


def kernel_time(k, W, G, M, tmax=200):
    tau = np.linspace(0, tmax, 20001)
    gam = lambda kk, ww: np.array([np.sum(ww * g * g * kk**2 / np.hypot(kk, M)**3 * np.cos(2 * np.hypot(kk, M) * t)) for t in tau])
    ref = gam(k, W); kB, WB, _ = group(k, W, np.zeros((3, len(k))), G)
    d = np.abs(gam(kB, WB) - ref); sc = np.max(np.abs(ref[tau > 1]))
    bad = tau[d > 0.1 * sc]
    return bad[0] if len(bad) else np.inf


def outcomes(tt, q, v, Z):
    res = []; i = 1
    while i < len(tt) - 1:
        if v[i-1] > 0 and v[i] <= 0 and q[i] > qb:
            E = Z * v[i]**2 / 2 + V(q[i]) - V(qt); j = i + 1; out = None
            while j < len(tt):
                if q[j-1] > qb and q[j] <= qb: out = 'C'; break
                if v[j-1] < 0 and v[j] >= 0: out = 'R'; break
                j += 1
            if out is None: break
            if E > V(qb) - V(qt): res.append((tt[i], out))
            i = j
        i += 1
    return res


