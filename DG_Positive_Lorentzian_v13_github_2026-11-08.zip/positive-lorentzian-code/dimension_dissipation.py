"""Horizon, dimension and dissipation of finite descriptions of the response continuum (Sections 7 and 9.1, Table 1, Figure 1a).

A  continuum kernel gamma(tau) = int rho(w) cos(w tau) dw (QAWO quadrature), Fejér count N(T, delta) of Eq. (26)
C  uniform cell-integral grid: horizons, period P = 2 pi G / dw, guaranteed horizon of Proposition 2
E  uniform grid with a common damping: smallest damping for horizons 300, 600, 1200; necessary damping at T* = pi int rho^2/delta^2
F  data needed to fix the linear force response on [0, T] (Gram eigenvalues of the transverse map); first-order data of D
G  other spectral densities (flat, linear, exponential, Drude, model): uniform, Gauss and logarithmic grids against the bound
H  age of the state: coherent fraction of block averages of the transverse amplitude along a reference trajectory
Writes data/dimension_dissipation.json.
"""
import json
import numpy as np
from scipy.integrate import quad, solve_ivp
from model import grid, Zbare, Vp, m0, g, qf, D
from prot import qi, Tp, tau_r, qpath, f as smooth

OUT = {}
K = 8.0; M = m0 + g * qf
wmin, wmax = 2 * abs(M), 2 * np.hypot(K, M); dw = wmax - wmin


def rho_model(w):
    k = np.sqrt(max((w / 2)**2 - M**2, 0.0)); return D * g * g * k**3 / (np.pi**2 * w**2)


def kernel(rho, a, b, tau):
    return np.array([quad(rho, a, b, weight='cos', wvar=t, limit=400)[0] if t > 0 else quad(rho, a, b, limit=400)[0] for t in tau])


def MT(gam, tau, T):
    m = tau <= T + 1e-12; t = tau[m]; return 2 * np.trapezoid((1 - t / T) * gam[m]**2, t) / T


def Nbound(gam, tau, T, delta):
    return (gam[0] - delta)**2 / (2 * (np.sqrt(MT(gam, tau, T)) + delta)**2)


def cells(rho, edges):
    return np.array([quad(rho, a, b, limit=200)[0] for a, b in zip(edges[:-1], edges[1:])])


def gauss_rule(rho, a, b, G, n=4000):
    xg, wg = np.polynomial.legendre.leggauss(n); xx = (xg + 1) * (b - a) / 2 + a
    mu = wg * (b - a) / 2 * np.array([rho(x) for x in xx]); nrm = mu.sum()
    V_ = np.zeros((n, G)); v = np.sqrt(mu / nrm); al = np.zeros(G); be = np.zeros(G); v_prev = np.zeros(n); bprev = 0.0
    for j in range(G):
        V_[:, j] = v; w = xx * v - bprev * v_prev; al[j] = v @ w; w = w - al[j] * v
        w = w - V_[:, :j + 1] @ (V_[:, :j + 1].T @ w)
        bnext = np.linalg.norm(w); be[j] = bnext; v_prev, v, bprev = v, w / bnext, bnext
    J = np.diag(al) + np.diag(be[:-1], 1) + np.diag(be[:-1], -1); nodes, vec = np.linalg.eigh(J)
    return nodes, nrm * vec[0]**2


def horizon(gG, gam, tau, delta):
    bad = tau[np.abs(gG - gam) > delta]; return float(bad[0]) if len(bad) else float('inf')


# ---------------- A ----------------
tau = np.arange(0, 1200.0001, 0.05)
gam = kernel(rho_model, wmin, wmax, tau)
delta = 0.20204585081276935                      # working tolerance (10% of max_{1<tau<=200}|gamma| of the 512-node kernel)
I2 = quad(lambda w: rho_model(w)**2, wmin, wmax, limit=400)[0]
Beff = gam[0]**2 / I2
ws = np.linspace(wmin, wmax, 400001); rv = np.array([rho_model(w) for w in ws[::20]])
V = abs(rv[0]) + abs(rv[-1]) + np.sum(np.abs(np.diff(rv)))
Tstar = np.pi * I2 / delta**2
OUT['A'] = dict(gamma0=gam[0], int_rho2=I2, B_eff=Beff, dw=dw, slope_lower=Beff / (2 * np.pi), slope_upper=dw / (2 * np.pi),
                delta=delta, V=V, Tstar=Tstar, TMT_1200=1200 * MT(gam, tau, 1200),
                N={str(T): Nbound(gam, tau, T, delta) for T in (3.43, 7.09, 10, 14.93, 30, 30.92, 100, 300, 600, 1200)})
print('A', json.dumps(OUT['A'], default=float))
# ---------------- C ----------------
OUT['C'] = []
for G in (16, 32, 64, 128, 256):
    edges = np.linspace(wmin, wmax, G + 1); mids = (edges[:-1] + edges[1:]) / 2; Wc = cells(rho_model, edges)
    hz = horizon(np.cos(np.outer(tau, mids)) @ Wc, gam, tau, delta); P = 2 * np.pi * G / dw
    den = delta - (np.pi / 3 + np.pi**2 / 6) * V / P
    guaranteed = P - V / den if den > 0 else None
    OUT['C'].append(dict(G=G, horizon=hz, P=P, P_minus_horizon=P - hz, guaranteed=guaranteed, ratio_to_N=G / Nbound(gam, tau, hz, delta),
                         slope_fraction=dw / (2 * np.pi) * hz / G))
print('C', OUT['C'])
# ---------------- E ----------------
OUT['E'] = []
for G in (64, 128, 192, 256):
    edges = np.linspace(wmin, wmax, G + 1); mids = (edges[:-1] + edges[1:]) / 2; Wc = cells(rho_model, edges)
    Cm = np.cos(np.outer(tau, mids)) * Wc; res = {'300': None, '600': None, '1200': None}
    for Gam in np.arange(0.0, 0.4001, 0.0025):
        err = np.abs((Cm * np.exp(-Gam * tau)[:, None]).sum(1) - gam)
        for Tmax in (300, 600, 1200):
            if res[str(Tmax)] is None and np.max(err[tau <= Tmax]) <= delta: res[str(Tmax)] = float(Gam)
        if all(v is not None for v in res.values()): break
    NT = Nbound(gam, tau, Tstar, delta)
    OUT['E'].append(dict(G=G, common_damping=res, total_damping={k_: (None if v is None else G * v) for k_, v in res.items()}))
OUT['E_estimate'] = dw / (2 * np.pi) * np.log(gam[0] / delta)
print('E', OUT['E'], OUT['E_estimate'])
# ---------------- F ----------------
k, W = grid(K, 512); E = np.hypot(k, M); c = -g * np.sqrt(W) * k / E
OUT['F'] = []
for T in (1.0, 3.43, 7.09, 14.93, 30.92):
    t = np.linspace(0, T, int(T * 200) + 1)
    Phi = np.concatenate([c[None, :] * np.cos(2 * np.outer(t, E)), c[None, :] * np.sin(2 * np.outer(t, E))], axis=1)   # (t, 2N)
    wt = np.full(len(t), t[1] - t[0]); wt[[0, -1]] /= 2
    Gram = Phi.T @ (Phi * wt[:, None]); lam = np.linalg.eigvalsh(Gram)[::-1]
    # first-order data of D on the transverse amplitudes: dF(0) and dFdot(0)
    d1 = np.concatenate([c, 0 * c]); d2 = np.concatenate([0 * c, 2 * E * c])
    Q, _ = np.linalg.qr(np.stack([d1, d2], 1)); Pp = np.eye(len(d1)) - Q @ Q.T
    lamD = np.linalg.eigvalsh(Pp @ Gram @ Pp)[::-1]
    OUT['F'].append(dict(T=T, LP_count=dw * T / np.pi, above_half=int(np.sum(lam >= lam[0] / 2)), above_tenth=int(np.sum(lam >= lam[0] / 10)),
                         participation=float(lam.sum()**2 / np.sum(lam**2)), top_with_D_fixed_over_top=float(lamD[0] / lam[0]),
                         above_half_with_D_fixed=int(np.sum(lamD >= lam[0] / 2))))
print('F', OUT['F'])
# ---------------- G ----------------
dens = {
    'flat': (lambda w: 1.0, 0.0, 1.0, lambda t: np.where(t == 0, 1.0, np.sin(t) / np.where(t == 0, 1, t)), np.arange(0, 900.0001, 0.1)),
    'linear': (lambda w: 2 * w, 0.0, 1.0, lambda t: np.where(t == 0, 1.0, 2 * ((np.cos(t) - 1) / np.where(t == 0, 1, t)**2 + np.sin(t) / np.where(t == 0, 1, t))), np.arange(0, 900.0001, 0.1)),
    'exponential': (lambda w: np.exp(-w), 0.0, 25.0, None, np.arange(0, 200.0001, 0.02)),
    'Drude': (lambda w: (2 / np.pi) / (1 + w * w), 0.0, 100.0, None, np.arange(0, 60.0001, 0.005)),
}
OUT['G'] = {}
for name, (rho, a, b, ker, tg) in dens.items():
    gk = ker(tg) if ker is not None else kernel(rho, a, b, tg)
    dl = 0.02 * gk[0]; I2d = quad(lambda w: rho(w)**2, a, b, limit=400)[0]; Bd = gk[0]**2 / I2d
    rows = []
    for G in (16, 32, 64):
        nodes, wts = gauss_rule(rho, a, b, G)
        eu = np.linspace(a, b, G + 1); mu_u = (eu[:-1] + eu[1:]) / 2; wu = cells(rho, eu)
        lo = a + (b - a) * 1e-4; el = np.concatenate([[a], lo * ((b / lo) ** (np.arange(G) / (G - 1)))]); ml = (el[:-1] + el[1:]) / 2; wl = cells(rho, el)
        rec = dict(G=G)
        for lab, (nd, wt_) in (('uniform', (mu_u, wu)), ('Gauss', (nodes, wts)), ('logarithmic', (ml, wl))):
            hz = horizon(np.cos(np.outer(tg, nd)) @ wt_, gk, tg, dl)
            rec[lab] = dict(horizon=hz, ratio_to_N=(G / Nbound(gk, tg, hz, dl)) if np.isfinite(hz) and hz > 0 else None)
        rows.append(rec)
    OUT['G'][name] = dict(gamma0=float(gk[0]), B_eff=Bd, band=b - a, slope_lower=Bd / (2 * np.pi), delta=dl, rows=rows)
    print('G', name, json.dumps(OUT['G'][name], default=float))
# Drude: one damped mode reproduces the untruncated kernel exp(-tau) exactly (W = 1, omega = 0, Gamma = 1)
OUT['G']['Drude']['one_damped_mode'] = 'exact: gamma(tau) = exp(-|tau|)'
# model row with the same discretizations
rows = []
for G in (16, 32, 64):
    nodes, wts = gauss_rule(rho_model, wmin, wmax, G)
    eu = np.linspace(wmin, wmax, G + 1); wu = cells(rho_model, eu); mu_u = (eu[:-1] + eu[1:]) / 2
    lo = wmin + dw * 1e-4; el = np.concatenate([[wmin], wmin + (lo - wmin) * ((wmax - wmin) / (lo - wmin)) ** (np.arange(G) / (G - 1))])
    ml = (el[:-1] + el[1:]) / 2; wl = cells(rho_model, el); rec = dict(G=G)
    for lab, (nd, wt_) in (('uniform', (mu_u, wu)), ('Gauss', (nodes, wts)), ('logarithmic', (ml, wl))):
        hz = horizon(np.cos(np.outer(tau, nd)) @ wt_, gam, tau, delta)
        rec[lab] = dict(horizon=hz, ratio_to_N=G / Nbound(gam, tau, hz, delta) if hz > 0 else None)
    rows.append(rec)
OUT['G']['model'] = dict(gamma0=float(gam[0]), B_eff=Beff, band=dw, slope_lower=Beff / (2 * np.pi), delta=delta, rows=rows)
print('G model', json.dumps(OUT['G']['model'], default=float))
# ---------------- H ----------------
N = 512; vs = -0.9; Zz = Zbare(K)
def modes_rhs(t, y):
    q = qpath(t, vs); Mq = m0 + g * q; s = y.reshape(3, N)
    return (2 * np.stack([-Mq * s[1], Mq * s[0] - k * s[2], k * s[1]])).ravel()
def full(t, y, ramp):
    q, v = y[0], y[1]; s = y[2:].reshape(3, N); Mq = m0 + g * q; Eq = np.hypot(k, Mq)
    F = g * np.sum(W * (s[2] + Mq / Eq)); acc = (-(Vp(q) + F) / Zz) * (smooth(min(t / tau_r, 1.0)) if ramp else 1.0)
    return np.concatenate([[v, acc], (2 * np.stack([-Mq * s[1], Mq * s[0] - k * s[2], k * s[1]])).ravel()])
M0 = m0 + g * qi; E0 = np.hypot(k, M0); s0 = np.stack([-k / E0, 0 * k, -M0 / E0])
sp = solve_ivp(modes_rhs, (0, Tp), s0.ravel(), method='DOP853', rtol=1e-10, atol=1e-12).y[:, -1]
y = solve_ivp(lambda t, y: full(t, y, True), (0, tau_r), np.concatenate([[qf, vs], sp]), method='DOP853', rtol=1e-10, atol=1e-12).y[:, -1]
ts = [2.0, 5.0, 10.0, 20.0, 40.0, 80.0]
r = solve_ivp(lambda t, y: full(t, y, False), (0, 80.0), y, method='DOP853', rtol=1e-10, atol=1e-12, t_eval=ts)
OUT['H'] = []
for j, t0 in enumerate(ts):
    yy = r.y[:, j]; q = yy[0]; Mq = m0 + g * q; Eq = np.hypot(k, Mq); s = yy[2:].reshape(3, N)
    a_ = (Mq * s[0] - k * s[2]) / Eq; b_ = s[1]; z = a_ + 1j * b_
    for G in (8, 16, 32, 64):
        bl = np.array_split(np.arange(N), G)
        num = sum(abs(np.sum(W[i] * z[i]))**2 / np.sum(W[i]) for i in bl); den = sum(np.sum(W[i] * abs(z[i])**2) for i in bl)
        OUT['H'].append(dict(t0=t0, age=t0 + Tp + tau_r, G=G, Kage_over_G=K * (t0 + Tp + tau_r) / G, coherent_fraction=float(num / den),
                             transverse_rms=float(np.sqrt(den / W.sum()))))
print('H', OUT['H'])
json.dump(OUT, open('data/dimension_dissipation.json', 'w'), indent=1, default=float)
