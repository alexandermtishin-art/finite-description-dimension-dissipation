"""Discretization comparisons of Supplement Table S2 and the random damped flat-spectrum example of Section 9.2.
Steps keep the phase increment of the highest frequency below 0.05 rad: exponential 0.002, Drude 0.0005, model 0.003;
flat and linear use 0.02 (frequencies below 1).
Writes data/table2_fine.json."""
import json
import numpy as np
from scipy.integrate import quad
from model import m0, g, qf, D
OUT = {}
K = 8.0; M = m0 + g * qf
wmin, wmax = 2 * abs(M), 2 * np.hypot(K, M); dw = wmax - wmin


def rho_model(w):
    k = np.sqrt(max((w / 2)**2 - M**2, 0.0)); return D * g * g * k**3 / (np.pi**2 * w**2)


def kernel(rho, a, b, tau):
    return np.array([quad(rho, a, b, weight='cos', wvar=t, limit=400)[0] if t > 0 else quad(rho, a, b, limit=400)[0] for t in tau])


def MT(gam, tau, T):
    m = tau <= T + 1e-12; t = tau[m]; return 2 * np.trapezoid((1 - t / T) * gam[m]**2, t) / T


def Nbound(gam, tau, T, delta):
    return (gam[0] - delta)**2 / (2 * (np.sqrt(MT(gam, tau, T)) + delta)**2)


def cells(rho, edges):
    return np.array([quad(rho, a, b, limit=200)[0] for a, b in zip(edges[:-1], edges[1:])])


def gauss_rule(rho, a, b, G, n=4000):
    xg, wg = np.polynomial.legendre.leggauss(n); xx = (xg + 1) * (b - a) / 2 + a
    mu = wg * (b - a) / 2 * np.array([rho(x) for x in xx]); nrm = mu.sum()
    V_ = np.zeros((n, G)); v = np.sqrt(mu / nrm); al = np.zeros(G); be = np.zeros(G); v_prev = np.zeros(n); bprev = 0.0
    for j in range(G):
        V_[:, j] = v; w = xx * v - bprev * v_prev; al[j] = v @ w; w = w - al[j] * v
        w = w - V_[:, :j + 1] @ (V_[:, :j + 1].T @ w)
        bnext = np.linalg.norm(w); be[j] = bnext; v_prev, v, bprev = v, w / bnext, bnext
    J = np.diag(al) + np.diag(be[:-1], 1) + np.diag(be[:-1], -1); nodes, vec = np.linalg.eigh(J)
    return nodes, nrm * vec[0]**2


def horizon(gG, gam, tau, delta):
    bad = tau[np.abs(gG - gam) > delta]; return float(bad[0]) if len(bad) else float('inf')



dens = {
    'flat': (lambda w: 1.0, 0.0, 1.0, lambda t: np.where(t == 0, 1.0, np.sin(t) / np.where(t == 0, 1, t)), np.arange(0, 900.0001, 0.02)),
    'linear': (lambda w: 2 * w, 0.0, 1.0, lambda t: np.where(t == 0, 1.0, 2 * ((np.cos(t) - 1) / np.where(t == 0, 1, t)**2 + np.sin(t) / np.where(t == 0, 1, t))), np.arange(0, 900.0001, 0.02)),
    'exponential': (lambda w: np.exp(-w), 0.0, 25.0, None, np.arange(0, 20.0001, 0.002)),
    'Drude': (lambda w: (2 / np.pi) / (1 + w * w), 0.0, 100.0, None, np.arange(0, 6.0001, 0.0005)),
    'model': (rho_model, wmin, wmax, None, np.arange(0, 25.0001, 0.003)),
}
for name, (rho, a, b, ker, tg) in dens.items():
    gk = ker(tg) if ker is not None else kernel(rho, a, b, tg)
    dl = 0.20204585081276935 if name == 'model' else 0.02 * gk[0]
    rows = []
    for G in (16, 32, 64):
        nodes, wts = gauss_rule(rho, a, b, G)
        eu = np.linspace(a, b, G + 1); mu_u = (eu[:-1] + eu[1:]) / 2; wu = cells(rho, eu)
        if name == 'model':
            lo = wmin + dw * 1e-4; el = np.concatenate([[wmin], wmin + (lo - wmin) * ((wmax - wmin) / (lo - wmin)) ** (np.arange(G) / (G - 1))])
        else:
            lo = a + (b - a) * 1e-4; el = np.concatenate([[a], lo * ((b / lo) ** (np.arange(G) / (G - 1)))])
        ml = (el[:-1] + el[1:]) / 2; wl = cells(rho, el); rec = dict(G=G)
        for lab, (nd, wt_) in (('uniform', (mu_u, wu)), ('Gauss', (nodes, wts)), ('logarithmic', (ml, wl))):
            hz = horizon(np.cos(np.outer(tg, nd)) @ wt_, gk, tg, dl)
            N = Nbound(gk, tg, hz, dl) if np.isfinite(hz) and hz > 0 else None
            rec[lab] = dict(horizon=hz, N=N, ratio_to_N=(G / N) if N else None)
        rows.append(rec)
    OUT[name] = dict(delta=dl, step=float(tg[1] - tg[0]), rows=rows)
    print(name, json.dumps(OUT[name], default=float), flush=True)
# random damped construction (flat spectrum, delta = 0.1, G = 1000): one random frequency per cell, common damping 5e-5
rng = np.random.default_rng(1 * 1000 + 1000); G = 1000; om = (np.arange(G) + rng.random(G)) / G; Gam = 5e-5
mx = 0.0
for t0 in np.arange(0, 6e4, 2000.0):
    t = np.arange(t0, t0 + 2000.0, 0.05)
    e = np.abs(np.cos(np.outer(t, om)).mean(1) * np.exp(-Gam * t) - np.sinc(t / np.pi)); mx = max(mx, float(e.max()))
OUT['random_damped_flat'] = dict(G=G, delta=0.1, Gamma=Gam, total=G * Gam, max_error_to_6e4=mx,
                                 tail_bound_beyond='exp(-Gamma*6e4) + 1/tau = %.3f + 1/tau' % np.exp(-Gam * 6e4))
print(OUT['random_damped_flat'], flush=True)
json.dump(OUT, open('data/table2_fine.json', 'w'), indent=1, default=float)
