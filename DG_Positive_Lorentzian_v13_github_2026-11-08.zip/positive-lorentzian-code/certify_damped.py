"""Rigorous all-time certificates for the three scalar-precession examples.

Requires python-flint (Arb ball arithmetic). No QUADPACK error estimate is
used as a proof. See NUMERICAL_VALIDATION.md for the analytic remainders.
Writes data/damped_certificates.json. The planning pass uses doubles only to
choose a partition; every reported inequality is checked again with Arb.
"""
from __future__ import annotations

import json
import math
import platform
from fractions import Fraction
from pathlib import Path
import sys
import time

import numpy as np

# Local development dependency, absent in a fresh installed environment.
_vendor = Path(__file__).resolve().parent.parent / "vendor"
if _vendor.is_dir():
    sys.path.insert(0, str(_vendor))
import flint
from flint import arb, ctx

ctx.prec = 128
ORDER = 768
TMAX = 110
DELTA = "0.20204585081276935"
SPECS = [
    (128, "0.07280390625", "0.2018"),
    (192, "0.049658984375", "0.2015"),
    (256, "0.0374", "0.20202"),
]


def rb(q: Fraction) -> arb:
    return arb(q.numerator) / q.denominator


def upper_float(x: arb) -> float:
    """Outward floating bound, used only for conservative JSON summaries."""
    return float(np.nextafter(float(x.upper()), np.inf))


def lower_float(x: arb) -> float:
    return float(np.nextafter(float(x.lower()), -np.inf))


def positive_root() -> arb:
    lo, hi = Fraction(9, 10), Fraction(1)
    for _ in range(112):
        q = (lo + hi) / 2
        v = rb(q)**3 - rb(q) + arb(1) / 20
        if v > 0:
            hi = q
        elif v < 0:
            lo = q
        else:
            raise ArithmeticError("Root bisection did not resolve the sign")
    # Cubic is increasing on [0.9,1], so its unique root is enclosed.
    return arb(rb((lo + hi) / 2), rb((hi - lo) / 2))


def main() -> None:
    started = time.monotonic()
    q = positive_root()
    m = -(arb(-6) / 5 + q)
    assert m > 0
    K = arb(8)
    C = arb(3) / arb.pi()**2
    E = (K*K + m*m).sqrt()
    a, b = 2*m, 2*E

    def primitive(k: arb) -> arb:
        z = (k*k + m*m).sqrt()
        return C * (k*z/2 + m*m*k/z - arb(3)*m*m*(k/m).asinh()/2)

    gamma0 = primitive(K)
    # rho is monotone on its band, whence total variation of its zero
    # extension is exactly twice its upper-end value.
    V = arb(3)*K**3/(arb.pi()**2*E**2)
    moment2 = C*(K*E*(2*K*K-3*m*m)+3*m**4*(K/m).asinh())/2

    rho_ellipse = arb(5)/4
    ellipse_A = K*(rho_ellipse+1/rho_ellipse)/4
    ellipse_B = K*(rho_ellipse-1/rho_ellipse)/4
    root_ellipse_norm = ((K/2/ellipse_A)**2+(m/ellipse_B)**2).sqrt()
    assert root_ellipse_norm > 1
    d = ellipse_B*(root_ellipse_norm-1)
    amplitude = C*(K/2+ellipse_A)**4/d**3
    remainder = (4*K*amplitude*(2*TMAX*ellipse_B).exp()
                 *rho_ellipse**(-2*ORDER)/(1-1/rho_ellipse))
    assert remainder < arb("1e-30")

    print("Constructing Arb Gauss rule", flush=True)
    nodes, measures, frequencies = [], [], []
    for j in range(ORDER):
        z, w = arb.legendre_p_root(ORDER, j, weight=True)
        k = K*(z+1)/2
        e = (k*k+m*m).sqrt()
        nodes.append(k)
        frequencies.append(2*e)
        measures.append(K*w*C*k**4/(2*e**3))
    print("Gauss rule ready; uniform remainder", remainder, flush=True)

    constructions = []
    for G, linewidth, target in SPECS:
        om, W = [], []
        previous = arb(0)
        for j in range(G):
            edge = a+(b-a)*arb(j+1)/G
            k = K if j+1 == G else ((edge/2)**2-m*m).sqrt()
            cumulative = primitive(k)
            W.append(cumulative-previous)
            previous = cumulative
            om.append(a+(b-a)*(arb(j)+arb(1)/2)/G)
        assert all(w > 0 for w in W)
        Gam = arb(linewidth)
        finite_m2 = sum((w*(o*o+Gam*Gam) for o,w in zip(om,W)),arb(0))
        tail = gamma0*(-Gam*TMAX).exp()+V/TMAX
        assert tail < arb(DELTA)
        constructions.append(dict(G=G,Gamma=Gam,linewidth=linewidth,target=arb(target),
                                  om=om,W=W,finite_m2=finite_m2,tail=tail))

    # Fast pass choosing a partition. This pass is not evidence by itself.
    of = np.array([float(x) for x in frequencies])
    wf = np.array([float(x) for x in measures])
    for c in constructions:
        c["of"] = np.array([float(x) for x in c["om"]])
        c["wf"] = np.array([float(x) for x in c["W"]])
    m2f = upper_float(moment2)
    cache = {}

    def errors(t: Fraction):
        if t not in cache:
            v=float(t)
            gamma=float(np.cos(of*v)@wf)
            cache[t]=[float(np.cos(c["of"]*v)@c["wf"])*math.exp(-float(c["Gamma"])*v)-gamma
                      for c in constructions]
        return cache[t]

    leaves=[]
    def partition(left:Fraction,right:Fraction,depth=0):
        e0,e1=errors(left),errors(right)
        h=float(right-left)
        ok=True
        for j,c in enumerate(constructions):
            m2=m2f+upper_float(c["finite_m2"])*math.exp(-float(c["Gamma"])*float(left))
            if max(abs(e0[j]),abs(e1[j]))+m2*h*h/8 >= float(c["target"])-1e-9:
                ok=False;break
        if ok:
            leaves.append((left,right))
        elif depth>=20:
            raise ArithmeticError("Subdivision limit")
        else:
            mid=(left+right)/2
            partition(left,mid,depth+1);partition(mid,right,depth+1)
    for i in range(TMAX*20):
        partition(Fraction(i,20),Fraction(i+1,20))
    points=sorted(set(x for interval in leaves for x in interval))
    print("Validating",len(points),"time nodes in",len(leaves),"intervals",flush=True)

    # Rigorous Arb pass over the selected exact rational nodes.
    validated={}
    for index,t in enumerate(points):
        tt=rb(t)
        gamma=sum((w*(o*tt).cos() for o,w in zip(frequencies,measures)),arb(0))
        vals=[]
        for c in constructions:
            f=sum((w*(o*tt).cos() for o,w in zip(c["om"],c["W"])),arb(0))*(-c["Gamma"]*tt).exp()
            vals.append(abs(f-gamma)+remainder)
        validated[t]=vals
        if index%1000==0:
            print("validated",index,"of",len(points),"elapsed",round(time.monotonic()-started,1),flush=True)

    maxima=[arb(0) for _ in constructions]
    sampled_lower=[arb(0) for _ in constructions]
    for left,right in leaves:
        h=rb(right-left)
        for j,c in enumerate(constructions):
            e0,e1=validated[left][j],validated[right][j]
            endpoint=e0.max(e1)
            m2=moment2+c["finite_m2"]*(-c["Gamma"]*rb(left)).exp()
            bound=endpoint+m2*h*h/8
            if not bound < c["target"]:
                raise ArithmeticError(f"Interval certificate failed: G={c['G']}, {left}, {right}, {bound}")
            maxima[j]=maxima[j].max(bound)
            sampled_lower[j]=sampled_lower[j].max(endpoint-2*remainder)

    out={"method":"Arb ball arithmetic + positive Gauss rule with analytic ellipse remainder + time interpolation + analytic tail",
         "precision_bits":ctx.prec,"gauss_order":ORDER,"certified_interval":[0,TMAX],
         "environment":{"python":platform.python_version(),"numpy":np.__version__,"python_flint":flint.__version__},
         "time_nodes":len(points),"time_intervals":len(leaves),
         "uniform_quadrature_remainder_upper":upper_float(remainder),
         "root_enclosure":str(q),"mass_parameter_enclosure":str(-m),
         "gamma0_enclosure":str(gamma0),"variation_enclosure":str(V),
         "moment2_enclosure":str(moment2),"delta":DELTA,"examples":[]}
    for j,c in enumerate(constructions):
        out["examples"].append(dict(G=c["G"],Gamma=c["linewidth"],
            total_linewidth=str(c["G"]*c["Gamma"]),
            verified_upper=upper_float(maxima[j]),
            evaluated_node_lower=lower_float(sampled_lower[j]),
            declared_rigorous_upper=str(c["target"]),
            tail_upper=upper_float(c["tail"]),
            all_time_certified=bool(maxima[j]<arb(DELTA) and c["tail"]<arb(DELTA))))
    out["elapsed_seconds"]=time.monotonic()-started
    Path("data").mkdir(exist_ok=True)
    Path("data/damped_certificates.json").write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out,indent=2),flush=True)


if __name__=="__main__":
    main()
