import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
eps,g,m0,D=0.05,1.0,-1.2,6
V=lambda q:(q*q-1)**2/4+eps*q
Vp=lambda q:q**3-q+eps
qt=brentq(Vp,-1.5,-0.5); qb=brentq(Vp,-0.5,0.5); qf=brentq(Vp,0.5,1.5)
def Zbare(K,mu=1.0):
    from scipy.integrate import quad
    return 1-D*g**2/(8*np.pi**2)*quad(lambda k:k**4/(k*k+mu*mu)**2.5,0,K)[0]
def grid(K,N):
    x,w=np.polynomial.legendre.leggauss(N); k=(x+1)*K/2; w=w*K/2
    return k,w*D*k**2/(2*np.pi**2)   # measure weights
def init_s(k,q,qd,kappa=None,n=None):
    M=m0+g*q; E=np.hypot(k,M)
    sy=-k*g*qd/(2*E**3)
    if kappa is not None: sy=sy*k**2/(k**2+kappa**2)
    s=np.stack([-k/E,sy,-M/E]); s/=np.linalg.norm(s,axis=0)
    return s
def rhs_factory(k,W,Z):
    N=len(k)
    def f(t,y):
        q,v=y[0],y[1]; s=y[2:].reshape(3,N)
        M=m0+g*q; E=np.hypot(k,M)
        F=g*np.sum(W*(s[2]+M/E))
        a=-(Vp(q)+F)/Z
        hx,hz=k,M
        ds=2*np.stack([-hz*s[1], hz*s[0]-hx*s[2], hx*s[1]])
        return np.concatenate([[v,a],ds.ravel()])
    return f
def energy(y,k,W,Z):
    N=len(k); q,v=y[0],y[1]; s=y[2:].reshape(3,N); M=m0+g*q; E=np.hypot(k,M)
    return Z*v*v/2+V(q)-V(qt)+np.sum(W*(E+k*s[0]+M*s[2]))
def occ(y,k):
    N=len(k); q=y[0]; s=y[2:].reshape(3,N); M=m0+g*q; E=np.hypot(k,M)
    return 0.5*(1+(k*s[0]+M*s[2])/E)

def rhs_exp(k,W,Z,P):
    N=len(k)
    def f(t,y):
        q,v,b=y[0],y[1],y[2]; s=y[3:].reshape(3,N); a=np.exp(b)
        M=m0+g*q; p=k/a; E=np.hypot(p,M)
        rnu=np.sum(W*(E+p*s[0]+M*s[2]))/a**3
        rho=Z*v*v/2+V(q)-V(qt)+rnu; H=np.sqrt(max(rho,0)/(3*P*P))
        F=g*np.sum(W*(s[2]+M/E))/a**3
        acc=-(Vp(q)+F)/Z-3*H*v
        ds=2*np.stack([-M*s[1], M*s[0]-p*s[2], p*s[1]])
        return np.concatenate([[v,acc,H],ds.ravel()])
    return f
def thermo_exp(y,k,W,Z):
    N=len(k); q,v,b=y[0],y[1],y[2]; s=y[3:].reshape(3,N); a=np.exp(b)
    M=m0+g*q; p=k/a; E=np.hypot(p,M)
    rnu=np.sum(W*(E+p*s[0]+M*s[2]))/a**3
    pnu=np.sum(W*(p/3)*(p/E+s[0]))/a**3
    rho=Z*v*v/2+V(q)-V(qt)+rnu; pr=Z*v*v/2-(V(q)-V(qt))+pnu
    return rho,pr
