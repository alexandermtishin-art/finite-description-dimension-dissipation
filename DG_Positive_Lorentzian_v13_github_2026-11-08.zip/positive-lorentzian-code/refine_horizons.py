"""Sampling check for Section 9.1 (Tables 1 and 2): horizons of the uniform grids and the all-horizon accuracy of the damped
uniform grids, recomputed against the continuum kernel on a step of 0.005 instead of 0.05.
Writes data/refine_horizons.json."""
import json
import numpy as np
from scipy.integrate import quad
from model import m0, g, qf, D
K = 8.0; M = m0 + g * qf
wmin, wmax = 2 * abs(M), 2 * np.hypot(K, M); dw = wmax - wmin


def rho_model(w):
    k = np.sqrt(max((w / 2)**2 - M**2, 0.0)); return D * g * g * k**3 / (np.pi**2 * w**2)


def kernel(rho, a, b, tau):
    return np.array([quad(rho, a, b, weight='cos', wvar=t, limit=400)[0] if t > 0 else quad(rho, a, b, limit=400)[0] for t in tau])


def MT(gam, tau, T):
    m = tau <= T + 1e-12; t = tau[m]; return 2 * np.trapezoid((1 - t / T) * gam[m]**2, t) / T


def Nbound(gam, tau, T, delta):
    return (gam[0] - delta)**2 / (2 * (np.sqrt(MT(gam, tau, T)) + delta)**2)


def cells(rho, edges):
    return np.array([quad(rho, a, b, limit=200)[0] for a, b in zip(edges[:-1], edges[1:])])


delta = 0.20204585081276935
out = {'uniform': [], 'damped': []}
tau = np.arange(0, 110.0, 0.005); gam = kernel(rho_model, wmin, wmax, tau)
for G in (16, 32, 64, 128, 256):
    e = np.linspace(wmin, wmax, G + 1); m = (e[:-1] + e[1:]) / 2; W = cells(rho_model, e)
    err = np.abs(np.cos(np.outer(tau, m)) @ W - gam); bad = tau[err > delta]
    out['uniform'].append(dict(G=G, horizon_fine=float(bad[0]) if len(bad) else None)); print(out['uniform'][-1], flush=True)
tau = np.arange(0, 1200.0001, 0.005); gam = kernel(rho_model, wmin, wmax, tau)
for G, Gam in ((128, 0.0726), (192, 0.0491), (256, 0.0374)):
    e = np.linspace(wmin, wmax, G + 1); m = (e[:-1] + e[1:]) / 2; W = cells(rho_model, e)
    mx = 0.0
    for i in range(0, len(tau), 20000):
        t = tau[i:i + 20000]; mx = max(mx, float(np.max(np.abs((np.cos(np.outer(t, m)) * np.exp(-Gam * t)[:, None]) @ W - gam[i:i + 20000]))))
    out['damped'].append(dict(G=G, Gamma=Gam, max_error=mx, ok=mx <= delta)); print(out['damped'][-1], flush=True)
json.dump(out, open('data/refine_horizons.json', 'w'), indent=1)
# smallest common damping rate on the fine grid (bisection to 1e-4), then a check at half the step
def maxerr(G, Gam, tau, gam):
    e = np.linspace(wmin, wmax, G + 1); m = (e[:-1] + e[1:]) / 2; W = cells(rho_model, e); mx = 0.0
    for i in range(0, len(tau), 20000):
        t = tau[i:i + 20000]; mx = max(mx, float(np.max(np.abs((np.cos(np.outer(t, m)) * np.exp(-Gam * t)[:, None]) @ W - gam[i:i + 20000]))))
    return mx
out['damped_refined'] = []
for G, lo, hi in ((128, 0.0726, 0.09), (192, 0.0491, 0.065), (256, 0.030, 0.0374)):
    while hi - lo > 1e-4:
        mid = (lo + hi) / 2
        if maxerr(G, mid, tau, gam) <= delta: hi = mid
        else: lo = mid
    out['damped_refined'].append(dict(G=G, Gamma=hi, total=G * hi)); print(out['damped_refined'][-1], flush=True)
t2 = np.arange(0, 1200.0001, 0.0025); g2 = kernel(rho_model, wmin, wmax, t2)
for r in out['damped_refined']:
    r['max_error_half_step'] = maxerr(r['G'], r['Gamma'], t2, g2); print(r, flush=True)
json.dump(out, open('data/refine_horizons.json', 'w'), indent=1)
