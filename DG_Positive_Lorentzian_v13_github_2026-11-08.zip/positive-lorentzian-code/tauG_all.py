"""Memory time tau_G (10% threshold, upper minimum) for all G used in the pair scan; writes data/tauG_GS.json."""
import json
import numpy as np
from model import grid, m0, g, qf
from grpred import group
k, W = grid(8.0, 512); tau = np.linspace(0, 200, 20001); M = m0 + g * qf   # same grid as kernel_thr.py
gam = lambda kk, ww: np.array([np.sum(ww * g * g * kk**2 / np.hypot(kk, M)**3 * np.cos(2 * np.hypot(kk, M) * t)) for t in tau])
ref = gam(k, W); sc = np.max(np.abs(ref[tau > 1])); out = {}
for G in (4, 8, 12, 16, 24, 32, 48, 64, 96, 128):
    kB, WB, _ = group(k, W, np.zeros((3, 512)), G); bad = tau[np.abs(gam(kB, WB) - ref) > 0.1 * sc]
    out[G] = float(bad[0]) if len(bad) else None
print(out); json.dump(out, open('data/tauG_GS.json', 'w'), indent=1)
