"""Small-width leakage of a trapezoid-weighted Cauchy line (remark after Theorem 1; Supplement S8).

For a cosine line at centre w0 in [0, Omega] and width Gamma -> 0, the mass placed in the weight 1 - chi
(chi = 1 on [-Omega, Omega], linear to 0 at |w| = R) is Gamma * kappa_R(w0) + o(Gamma), with
kappa_R(w0) = (1/(2 pi)) sum_{+-} int (1 - chi(w)) / (w -+ w0)^2 dw.
The script evaluates min over w0 of kappa_R by quadrature on a grid of centres and the effective
coefficient C_R / min kappa_R, compared with beta_R = 2 R C_R of Theorem 1 (Omega = 1).
Writes data/leakage_refined.json. Numerical quadrature, not an interval certificate."""
import json
import numpy as np
from scipy.integrate import quad

OM = 1.0


def chi(w, R):
    w = abs(w)
    return 1.0 if w <= OM else max(0.0, (R - w) / (R - OM))


def kappa(w0, R):
    def one(c):
        f = lambda w: (1 - chi(w, R)) / (np.pi * (w - c) ** 2)
        return sum(quad(f, a, b, limit=200)[0] for a, b in [(-np.inf, -R), (-R, -OM), (OM, R), (R, np.inf)])
    return 0.5 * (one(w0) + one(-w0))


rows = []
centres = np.linspace(0, 0.999, 40)
for x in [2 ** 0.5, 1.6, 1.8, 2.0, 2.5]:
    R = x * OM
    ks = [kappa(c, R) for c in centres]
    C = 1 + np.sqrt((R + OM) / (R - OM))
    k = min(ks)
    rows.append(dict(R_over_Omega=round(x, 4), min_kappa=k, argmin_centre=float(centres[int(np.argmin(ks))]),
                     kappa_at_0_closed_form=(2 / np.pi) * np.log(x) / (x - 1),
                     effective_coefficient=C / k, beta_R_theorem1=2 * R * C))
    print('R/Omega=%.3f  min kappa=%.4f at w0=%.3f  C_R/min kappa=%.3f  beta_R=%.3f' %
          (x, k, rows[-1]['argmin_centre'], C / k, 2 * R * C))
json.dump(rows, open('data/leakage_refined.json', 'w'), indent=1)
