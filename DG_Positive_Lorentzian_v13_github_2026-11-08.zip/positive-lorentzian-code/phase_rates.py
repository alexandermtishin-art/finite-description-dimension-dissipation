"""Cramer--Bessel horizon rate and exact independent-phase moment constants.

Run with Python 3.10+, numpy and scipy. The default output is
data/phase_rates.json relative to the script folder; --output may select another path.
No random grids or first-failure times are simulated here.  The computations
evaluate the analytic achievable rate and exact finite-size moment obstructions.
"""

from __future__ import annotations

import argparse
from decimal import Decimal, localcontext
from fractions import Fraction
import json
from math import ceil, comb, e, factorial, fsum, log, log1p
from pathlib import Path

from scipy.optimize import brentq
from scipy.special import i0e, i1e


A0_TEXT = "9.6470233149044928"
DELTA_TEXT = "0.20204585081276935"
A0 = float(A0_TEXT)
DELTA = float(DELTA_TEXT)


def log_i0(s: float) -> float:
    """Avoid cancellation of log(i0e(s))+s at small saddle values."""
    if s > 10.0:
        return log(float(i0e(s))) + s
    terms = []
    term = 1.0
    for n in range(1, 401):
        term *= (s / (2.0 * n)) ** 2
        terms.append(term)
        if n >= 2 and term < 1e-18 * max(1.0, fsum(terms)):
            break
    return log1p(fsum(terms))


def phase_rate(r: float) -> dict:
    """Legendre transform of log I0 at 0<r<1, using scaled Bessel functions."""
    if not 0.0 < r < 1.0:
        raise ValueError("The relative tolerance must lie in (0,1).")
    hi = 1.0
    while i1e(hi) / i0e(hi) < r:
        hi *= 2.0
    saddle = brentq(
        lambda s: i1e(s) / i0e(s) - r,
        0.0,
        hi,
        xtol=5e-15,
        rtol=1e-14,
    )
    rate = saddle * r - log_i0(saddle)
    old_rate = r * r / 2.0
    return {
        "relative_error": r,
        "saddle": saddle,
        "cramer_rate": rate,
        "hoeffding_rate": old_rate,
        "gain": rate / old_rate,
        "small_r_quartic": r * r + r**4 / 4.0,
    }


def multiply_truncated(a: list[Fraction], b: list[Fraction], order: int) -> list[Fraction]:
    out = [Fraction(0) for _ in range(min(order + 1, len(a) + len(b) - 1))]
    for j, av in enumerate(a):
        for ell, bv in enumerate(b[: max(0, order - j + 1)]):
            out[j + ell] += av * bv
    return out


def exact_phase_moment(G: int, k: int) -> Fraction:
    """E[(G^-1 sum_{j=1}^G cos(phi_j))^(2k)] for independent uniform phases.

    In the variable w=z^2 the I0 series is sum w^n/(4^n (n!)^2).
    Polynomial exponentiation by squaring is exact over the rational numbers.
    """
    if G < 1 or k < 1:
        raise ValueError("G and k must be positive integers.")
    base = [Fraction(1, 4**n * factorial(n) ** 2) for n in range(k + 1)]
    power = [Fraction(1)]
    remaining = G
    while remaining:
        if remaining & 1:
            power = multiply_truncated(power, base, k)
        remaining >>= 1
        if remaining:
            base = multiply_truncated(base, base, k)
    coefficient = power[k]
    return Fraction(factorial(2 * k), G ** (2 * k)) * coefficient


def encode_fraction(value: Fraction) -> dict:
    return {
        "numerator": str(value.numerator),
        "denominator": str(value.denominator),
        "decimal": float(value),
    }


def decimal_rate_crosscheck() -> dict:
    """Independent 60-digit power-series and bisection calculation of the main rate."""
    with localcontext() as ctx:
        ctx.prec = 60
        r = Decimal(DELTA_TEXT) / Decimal(A0_TEXT)

        def bessel_pair(s: Decimal) -> tuple[Decimal, Decimal]:
            z = s * s / 4
            term0, term1 = Decimal(1), s / 2
            value0, value1 = term0, term1
            for n in range(1, 1000):
                term0 *= z / (n * n)
                term1 *= z / (n * (n + 1))
                value0 += term0
                value1 += term1
                if abs(term0) + abs(term1) < Decimal("1e-62"):
                    break
            return value0, value1

        lo, hi = Decimal(0), Decimal(1)
        while bessel_pair(hi)[1] / bessel_pair(hi)[0] < r:
            hi *= 2
        for _ in range(220):
            mid = (lo + hi) / 2
            value0, value1 = bessel_pair(mid)
            if value1 / value0 > r:
                hi = mid
            else:
                lo = mid
        saddle = (lo + hi) / 2
        value0, _ = bessel_pair(saddle)
        rate = saddle * r - value0.ln()
        return {
            "method": "60-digit standard-library Decimal series for I0/I1 and 220 bisection steps; not a directed-rounding interval certificate.",
            "A0_decimal_input": A0_TEXT,
            "delta_decimal_input": DELTA_TEXT,
            "relative_error_decimal": str(r),
            "saddle_decimal": str(saddle),
            "cramer_rate_decimal": str(rate),
        }


def moment_records() -> tuple[list[dict], dict]:
    records = []
    closed_form_checks = []
    for G in (1, 2, 4, 16, 64, 256):
        m1 = exact_phase_moment(G, 1)
        m2 = exact_phase_moment(G, 2)
        first_expected = Fraction(1, 2 * G)
        second_expected = Fraction(3 * (2 * G - 1), 8 * G**3)
        if m1 != first_expected or m2 != second_expected:
            raise ArithmeticError("Exact phase moment disagrees with its closed form.")
        closed_form_checks.append({"G": G, "m1_exact": True, "m2_exact": True})
        for k in (1, 2, 3, 4, 8):
            value = exact_phase_moment(G, k)
            rec = {"G": G, "k": k, "C_G_k": encode_fraction(value)}
            if k <= G:
                distinct = Fraction(factorial(2 * k) * comb(G, k), 4**k * G ** (2 * k))
                if value < distinct:
                    raise ArithmeticError("Exact moment is below its retained-distinct-phase terms.")
                elementary = (k * (G - k + 1) / (e * G**2)) ** k
                rec.update(
                    distinct_phase_lower=encode_fraction(distinct),
                    elementary_lower=elementary,
                    exact_over_distinct=float(value / distinct),
                    exact_over_elementary=float(value) / elementary,
                )
            records.append(rec)
    checks = {
        "independent_closed_forms": {
            "m1": "1/(2G)",
            "m2": "3(2G-1)/(8G^3)",
        },
        "checks": closed_form_checks,
        "all_passed": True,
    }
    return records, checks


def signed_finite_bound(n: int, epsilon: Fraction) -> dict:
    """Necessary G from the displayed Hadamard-power inequality at its stated k.

    This is a necessary rank obstruction, not an optimized construction or a
    claim that every G at or above the returned value attains the target kernel.
    """
    k = ceil(log(n) / (2.0 * log(1.0 / float(epsilon))))
    rhs = Fraction(n, 1) / (1 + (n - 1) * epsilon ** (2 * k))

    def permitted(G: int) -> bool:
        return comb(2 * G + k - 1, k) >= rhs

    lo, hi = 0, 1
    while not permitted(hi):
        hi *= 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if permitted(mid):
            hi = mid
        else:
            lo = mid
    return {
        "n": n,
        "epsilon": str(epsilon),
        "k": k,
        "rank_lower_rhs": encode_fraction(rhs),
        "minimum_G_allowed_by_this_inequality": hi,
        "G_over_log_n": hi / log(n),
        "lhs_at_G": str(comb(2 * hi + k - 1, k)),
        "previous_G_excluded": hi == 1 or not permitted(hi - 1),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent / "data" / "phase_rates.json")
    args = parser.parse_args()
    actual = phase_rate(DELTA / A0)
    moments, checks = moment_records()
    data = {
        "A0": A0,
        "delta": DELTA,
        **actual,
        "rate_interpretation": "Proved achievable log-horizon rate; not the exact optimal exponent or an expected first-failure rate.",
        "other_relative_tolerances": [phase_rate(r) for r in (0.02, 0.05, 0.1, 0.2, 0.4)],
        "exact_phase_moments": moments,
        "moment_identity_checks": checks,
        "signed_finite_rank_obstructions": [
            signed_finite_bound(n, Fraction(eps))
            for eps in ("0.1", "0.25", "0.49", "0.9")
            for n in (1000, 1000000, 1000000000)
        ],
        "method": {
            "rate": "Scaled I0/I1 Bessel functions and scalar root of I1(s)/I0(s)=r; log1p of the I0 power series avoids small-saddle cancellation.",
            "moments": "Exact rational coefficient extraction from I0(z)^G via truncated polynomial exponentiation.",
            "rank": "Exact integer binomial coefficients compared with rational right-hand side.",
        },
        "decimal_crosscheck": decimal_rate_crosscheck(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: data[key] for key in ("A0", "delta", "relative_error", "cramer_rate", "hoeffding_rate", "gain")}, indent=2))
    print("Exact moments: 30 records; 12 independent closed-form identity checks passed.")
    print("Signed finite-rank obstruction: 12 exact-arithmetic records.")
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
