"""Figure 1: (a) lower bounds and constructions for the scalar-precession kernel; (b) uniform vs random grids, flat spectrum.
Reads data/dimension_dissipation.json, data/rank_bound.json, data/long_horizon.json; writes p1_fig1.png."""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

d = json.load(open('data/dimension_dissipation.json')); r = json.load(open('data/rank_bound.json'))['model']
lh = json.load(open('data/long_horizon.json'))['flat']
A = d['A']; dw = A['dw']
fig, ax = plt.subplots(1, 2, figsize=(10, 4))
N = sorted((float(k), v) for k, v in A['N'].items() if k != '30')
ax[0].plot([t for t, _ in N], [v for _, v in N], 'k-o', ms=3, label='positive Fejér bound')
for key, lab, m in (('rank_bound', r'rank, $\delta=0.202$', 's'), ('rank_bound_d05', r'rank, $\delta=0.05$', '^'), ('rank_bound_d01', r'rank, $\delta=0.01$', 'v')):
    ax[0].plot([x['T'] for x in r], [x[key] for x in r], '--', marker=m, ms=4, label=lab)
T = np.logspace(0, np.log10(1200), 100)
ax[0].plot(T, dw * T / (2 * np.pi), ':', color='gray', label=r'$(b-a)T/2\pi$')
ax[0].axhline(A['saturation'] if 'saturation' in A else (A['gamma0'] - A['delta'])**2 / (2 * A['delta']**2), color='gray', lw=0.8)
rf = json.load(open('data/refine_horizons.json'))['uniform']
ax[0].plot([c['horizon_fine'] for c in rf], [c['G'] for c in rf], 'D', color='C3', label='uniform grid')
ax[0].plot([3.43, 7.09, 14.93, 30.92], [16, 32, 64, 128], 'o', mfc='none', color='C4', label='block reduction')
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].set_xlabel('horizon $T$'); ax[0].set_ylabel('number of modes $G$')
ax[0].set_title('(a) scalar–precession kernel', fontsize=10); ax[0].legend(fontsize=7)
for dd, m in ((0.02, 'o'), (0.05, 's'), (0.1, '^')):
    rows = [x for x in lh if x['delta'] == dd]
    ls = {0.02: '-', 0.05: '-.', 0.1: ':'}[dd]
    ax[1].plot([x['G'] for x in rows], [x['uniform'] for x in rows], ls, marker=m, color='C0', label=rf'uniform, $\delta={dd}$')
    fin = [x for x in rows if x['jittered'] < 2e4]; cen = [x for x in rows if x['jittered'] >= 2e4]
    ax[1].plot([x['G'] for x in fin], [x['jittered'] for x in fin], '--', marker=m, mfc='none', color='C1', label=rf'random (median of 5), $\delta={dd}$')
    if cen: ax[1].plot([x['G'] for x in cen], [x['jittered'] for x in cen], marker='$\\uparrow$', ms=14, ls='none', color='C1')
ax[1].axhline(2e4, color='gray', lw=0.8); ax[1].text(260, 2.2e4, 'end of computation', fontsize=7)
ax[1].set_xscale('log'); ax[1].set_yscale('log'); ax[1].set_xlabel('number of modes $G$'); ax[1].set_ylabel('first failure time')
ax[1].set_title('(b) flat spectrum', fontsize=10); ax[1].legend(fontsize=7)
plt.tight_layout(); plt.savefig('outputs/p1_fig1.png', dpi=200)
