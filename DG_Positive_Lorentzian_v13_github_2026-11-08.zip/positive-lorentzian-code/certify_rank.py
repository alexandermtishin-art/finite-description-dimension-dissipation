"""Validated lower bounds from exact piecewise-constant Galerkin compressions.

The positive operator compression has eigenvalues below those of the full
convolution operator. Consequently its certified spectral tails give valid
continuum rank lower bounds without claiming that Nystrom values are exact.
Arb verifies a polar-decomposition residual enclosure of all eigenvalues.
"""
from __future__ import annotations
import json
import time
import sys
import platform
from pathlib import Path
import numpy as np
from scipy.linalg import eigh, toeplitz
import scipy
from certify_damped import arb, ctx, positive_root, upper_float, lower_float
from flint import arb_mat
import flint

ctx.prec=128
ORDER=768


def frobenius_bound(A):
    return sum((A[i,j]**2 for i in range(A.nrows()) for j in range(A.ncols())),arb(0)).sqrt().upper()


def main():
    start=time.monotonic()
    q=positive_root();m=arb(6)/5-q
    K=arb(8);C=arb(3)/arb.pi()**2
    rho=arb(5)/4
    Aa=K*(rho+1/rho)/4;Bb=K*(rho-1/rho)/4
    dn=Bb*(((K/2/Aa)**2+(m/Bb)**2).sqrt()-1)
    amp=C*(K/2+Aa)**4/dn**3
    frequencies=[];weights=[]
    for j in range(ORDER):
        z,w=arb.legendre_p_root(ORDER,j,weight=True)
        k=K*(z+1)/2;e=(k*k+m*m).sqrt()
        frequencies.append(2*e);weights.append(K*w*C*k**4/(2*e**3))
    rows=[]
    selected=[("3.22",256),("14.93",512),("46.41",1024)]
    all_rows=[("3.22",256),("3.43",256),("7.09",256),("8.73",256),
              ("14.93",512),("21.08",512),("30.92",1024),
              ("46.41",1024),("97.83",2048)]
    full="--all" in sys.argv
    for t_string,n in all_rows if full else selected:
        T=arb(t_string);h=T/n
        # |sinc(omega h/2)|^2 <= exp(2 h Bb) on the ellipse.
        remainder=(4*K*amp*(2*(T+h)*Bb).exp()*rho**(-2*ORDER)/(1-1/rho))*h
        ws=[w*((o*h/2).sin()/(o*h/2))**2 for o,w in zip(frequencies,weights)]
        cov=[]
        for j in range(n):
            x=h*sum((w*(o*h*j).cos() for o,w in zip(frequencies,ws)),arb(0))
            cov.append(x+arb(0,remainder))
        B=toeplitz(np.array([float(x) for x in cov]))
        lam,Q=eigh(B,check_finite=False,driver="evd")
        # Q and lambda are treated as exact dyadic numbers; every operation
        # in the residual verification below is interval arithmetic.
        A=arb_mat([[cov[abs(i-j)] for j in range(n)] for i in range(n)])
        U=arb_mat(Q.tolist())
        UD=arb_mat([[arb(float(Q[i,j]))*arb(float(lam[j])) for j in range(n)] for i in range(n)])
        R=A*U-UD
        orth=U.transpose()*U-arb_mat(np.eye(n).tolist())
        eta=frobenius_bound(orth)
        assert eta<arb("0.001")
        smin=(1-eta).sqrt()
        dist=eta/(1+smin)
        residual=frobenius_bound(R)
        lmax=arb(float(np.max(np.abs(lam))))
        eig_error=((residual+2*dist*lmax)/smin).upper()
        vals=[(arb(float(v))-eig_error).lower().max(0) for v in lam[::-1]]
        tail=[arb(0)]*(n+1)
        for j in range(n-1,-1,-1):tail[j]=tail[j+1]+vals[j]**2
        record={"T":t_string,"galerkin_dimension":n,"basis":"normalized indicators of equal cells",
                "eigenvalue_error_upper":upper_float(eig_error),
                "orthogonality_defect_upper":upper_float(eta),
                "residual_frobenius_upper":upper_float(residual),"bounds":{}}
        for ds in ["0.20204585081276935","0.05","0.01"]:
            tol=T*T*arb(ds)**2
            required=next(j for j in range(n+1) if not tail[j]>tol)
            # All smaller ranks have a certified tail above the error budget.
            record["bounds"][ds]={"required_operator_rank_at_least":required,
                "mode_bound_before_integer_rounding":required/2,
                "integer_mode_bound":(required+1)//2,
                "last_excluded_rank":required-1,
                "last_excluded_tail_lower":lower_float(tail[required-1]) if required else None,
                "error_budget_upper":upper_float(tol)}
        rows.append(record)
        print(json.dumps(record),flush=True)
    out={"method":"validated Galerkin compression, positive-operator minmax, Arb eigenvalue residual and spectral tails",
         "precision_bits":ctx.prec,"gauss_order":ORDER,
         "environment":{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"python_flint":flint.__version__},
         "rows":rows,"elapsed_seconds":time.monotonic()-start}
    filename="rank_certificates_all.json" if full else "rank_certificates.json"
    Path("data",filename).write_text(json.dumps(out,indent=2)+"\n")
    print("elapsed",out["elapsed_seconds"],flush=True)


if __name__=="__main__":main()
