"""Two-coordinate construction for the multichannel counting theorem.

The rotating rank-one density and the rank-two independent density have the
same trace spectrum and K(0)=I_2. Both are supported on [0,1]. This script
checks the analytic kernels and reports numerical first-failure horizons of
explicit midpoint constructions at the same total scalar-oscillator count.
These sampled/locally refined horizons are illustrations, not certificates
of optimality and not proofs of the asymptotic theorem.

Run: python matrix_example.py [--output data/matrix_channels.json]
Dependencies: numpy, scipy.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq


def sinc(x):
    return np.sinc(np.asarray(x) / np.pi)


def gfun(x):
    """(1-cos(x))/x with its continuous value zero at x=0."""
    x = np.asarray(x)
    return 0.5 * x * np.sinc(x / (2.0 * np.pi)) ** 2


def exact_kernel(t, kind):
    t = np.atleast_1d(np.asarray(t, dtype=float))
    base = sinc(t)
    result = np.zeros((len(t), 2, 2))
    if kind == "independent":
        result[:, 0, 0] = result[:, 1, 1] = base
    elif kind == "rotating":
        cterm = 0.5 * (sinc(t + 2 * np.pi) + sinc(t - 2 * np.pi))
        sterm = 0.5 * (gfun(2 * np.pi + t) + gfun(2 * np.pi - t))
        result[:, 0, 0] = base + cterm
        result[:, 1, 1] = base - cterm
        result[:, 0, 1] = result[:, 1, 0] = sterm
    else:
        raise ValueError(kind)
    return result


def matrix_density(w, kind):
    if kind == "independent":
        return np.eye(2)
    u = np.array([np.cos(np.pi * w), np.sin(np.pi * w)])
    return 2 * np.outer(u, u)


def midpoint_rule(total_oscillators, kind):
    if kind == "rotating":
        nodes = (np.arange(total_oscillators) + 0.5) / total_oscillators
        weights = np.array([matrix_density(w, kind) for w in nodes]) / len(nodes)
    elif kind == "independent":
        if total_oscillators % 2:
            raise ValueError("Independent construction uses an even oscillator count")
        n = total_oscillators // 2
        nodes = (np.arange(n) + 0.5) / n
        weights = np.repeat(np.eye(2)[None, :, :], n, axis=0) / n
    else:
        raise ValueError(kind)
    return nodes, weights


def approximation(t, nodes, weights):
    t = np.atleast_1d(np.asarray(t, dtype=float))
    result = np.empty((len(t), 2, 2))
    for start in range(0, len(t), 4096):
        tt = t[start:start + 4096]
        result[start:start + len(tt)] = np.einsum(
            "tn,nij->tij", np.cos(np.outer(tt, nodes)), weights, optimize=True
        )
    return result


def first_failure(total_oscillators, kind, delta, step=0.01):
    nodes, weights = midpoint_rule(total_oscillators, kind)
    end = 2 * np.pi * total_oscillators + 8 * np.pi
    grid = np.arange(0.0, end + step, step)
    errors = np.linalg.norm(
        approximation(grid, nodes, weights) - exact_kernel(grid, kind), axis=(1, 2)
    )
    indices = np.flatnonzero(errors > delta)
    if not len(indices):
        return {"horizon": None, "searched_to": float(grid[-1])}
    first = int(indices[0])
    if first == 0:
        root = 0.0
    else:
        def threshold(t):
            return float(np.linalg.norm(
                approximation([t], nodes, weights)[0] - exact_kernel([t], kind)[0]
            ) - delta)
        root = brentq(threshold, float(grid[first - 1]), float(grid[first]), xtol=1e-12)
    return {
        "horizon": float(root),
        "first_failing_grid_time": float(grid[first]),
        "frequency_nodes": int(len(nodes)),
        "scalar_oscillators": int(total_oscillators),
    }


def checks():
    maximum_kernel_error = 0.0
    points = [0.0, 0.1, 1.0, 2 * np.pi - 1e-8, 2 * np.pi,
              2 * np.pi + 1e-8, 17.3, 100.0]
    for kind in ("rotating", "independent"):
        for t in points:
            numerical = np.empty((2, 2))
            for i in range(2):
                for j in range(2):
                    numerical[i, j] = quad(
                        lambda w: matrix_density(w, kind)[i, j],
                        0.0, 1.0, weight="cos", wvar=t,
                        epsabs=1e-12, epsrel=1e-12
                    )[0]
            maximum_kernel_error = max(maximum_kernel_error,
                                       float(np.linalg.norm(numerical - exact_kernel([t], kind)[0])))
        assert np.allclose(exact_kernel([0], kind)[0], np.eye(2), atol=1e-13, rtol=0)
    assert maximum_kernel_error < 1e-11
    return {"analytic_kernel_vs_quadrature_max_Frobenius_error": maximum_kernel_error,
            "number_of_times_per_model": len(points), "same_K0": True,
            "same_trace_density": 2.0, "same_positive_frequency_band": [0.0, 1.0]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent / "data" / "matrix_channels.json")
    args = parser.parse_args()
    result = {
        "description": "Explicit midpoint constructions at equal scalar-oscillator counts",
        "error_norm": "uniform Frobenius norm on [0,T]",
        "delta": 0.02,
        "time_grid_step": 0.01,
        "qualification": "Numerical first crossings; no all-interval certificate or optimality claim",
        "theorem_regime": "T delta(T)^2 -> 0 and T delta(T) -> infinity",
        "leading_optimal_G_per_T": {"rotating_rank_one": 1 / (2 * np.pi),
                                   "independent_rank_two": 1 / np.pi},
        "checks": checks(),
        "rows": [],
    }
    for total in (16, 32, 64, 128):
        row = {"G": total}
        for kind in ("rotating", "independent"):
            row[kind] = first_failure(total, kind, result["delta"])
        row["rotating_to_independent_horizon_ratio"] = (
            row["rotating"]["horizon"] / row["independent"]["horizon"]
        )
        result["rows"].append(row)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
