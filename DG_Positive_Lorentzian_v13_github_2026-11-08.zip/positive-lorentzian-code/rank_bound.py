"""Rank (Eckart-Young) lower bound on the number of undamped modes, weights of any sign.

An undamped reduction with G modes gives a convolution operator on L^2(0,T) of rank <= 2G. If |gamma_G - gamma| <= delta on
[-T,T], the Hilbert-Schmidt distance is at most T delta, so sum_{n>2G} lambda_n(K_T)^2 <= T^2 delta^2 and
G >= m(T,delta)/2, m = min{m : sum_{n>m} lambda_n^2 <= T^2 delta^2}.
Cases: the model kernel (continuum, working tolerance and smaller); flat spectrum on [0,1] (limit 1/(2 pi) = 0.159 per unit time);
Drude spectrum (infinite support; the bound per unit time grows as delta decreases).
Also: eigenvalue counts above fractions of the largest eigenvalue against the Landau count (b-a) T / pi.
Writes data/rank_bound.json.
"""
import json
import numpy as np
from scipy.integrate import quad
from model import m0, g, qf, D

K = 8.0; M = m0 + g * qf; wmin, wmax = 2 * abs(M), 2 * np.hypot(K, M)
def rho(w):
    k = np.sqrt(max((w / 2)**2 - M**2, 0.0)); return D * g * g * k**3 / (np.pi**2 * w**2)


def eigs(kfun, T, h):
    n = int(round(T / h)); t = (np.arange(n) + 0.5) * T / n
    return np.sort(np.linalg.eigvalsh(kfun(np.abs(t[:, None] - t[None, :])) * (T / n)))[::-1]


def mbound(lam, T, delta):
    # Include the empty tail after full rank. np.argmax on an all-False
    # vector returned zero in the old implementation at extreme accuracies.
    tail = np.r_[np.cumsum((lam**2)[::-1])[::-1], 0.0]
    return int(np.flatnonzero(tail <= T * T * delta * delta)[0]) / 2


out = {}
tau = np.arange(0, 120.0001, 0.01)
gam = np.array([quad(rho, wmin, wmax, weight='cos', wvar=t, limit=400)[0] if t > 0 else quad(rho, wmin, wmax)[0] for t in tau])
kmod = lambda x: np.interp(x, tau, gam)
rows = []
for T in (3.22, 3.43, 7.09, 8.73, 14.93, 21.08, 30.92, 46.41, 97.83):   # block and uniform-grid horizons (step 0.005)
    lam = eigs(kmod, T, 0.04)
    rows.append(dict(T=T, rank_bound=mbound(lam, T, 0.20204585081276935), rank_bound_d05=mbound(lam, T, 0.05), rank_bound_d01=mbound(lam, T, 0.01),
                     above_tenth=int(np.sum(lam > 0.1 * lam[0])), above_hundredth=int(np.sum(lam > 0.01 * lam[0])), landau=(wmax - wmin) * T / np.pi))
    print(rows[-1], flush=True)
out['model'] = rows
flat = lambda x: np.where(x == 0, 1.0, np.sin(x) / np.where(x == 0, 1, x))
rows = []
for T in (100.0, 200.0, 400.0):
    lam = eigs(flat, T, 0.2)
    rows.append(dict(T=T, per_T={str(dd): mbound(lam, T, dd) / T for dd in (0.02, 0.005, 0.001)}))
    print('flat', rows[-1], flush=True)
out['flat'] = dict(limit=1 / (2 * np.pi), rows=rows)
drude = lambda x: np.exp(-x)
rows = []
for T in (10.0, 20.0):
    lam = eigs(drude, T, 0.005)
    rows.append(dict(T=T, per_T={str(dd): mbound(lam, T, dd) / T for dd in (0.02, 0.005, 0.001)}))
    print('drude', rows[-1], flush=True)
out['Drude'] = rows
json.dump(out, open('data/rank_bound.json', 'w'), indent=1)
