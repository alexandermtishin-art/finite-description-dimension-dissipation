"""Figure 3: analytic accuracy barriers and an equal-trace matrix pair.

No approximation problem is optimized numerically. Every count in the data
tables is an Arb-validated evaluation of a proved analytic bound. The inset
shows exact spectral directions evaluated for display. Requires numpy,
matplotlib and python-flint; see ACCURACY_BARRIER.md for the formulas.

Run from any directory: python accuracy_barrier.py
"""

from __future__ import annotations

import argparse
import csv
from decimal import Decimal
import json
import platform
from pathlib import Path

import flint
from flint import arb, ctx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator, NullFormatter
import numpy as np


def lower_float(x: arb) -> float:
    return float(np.nextafter(float(x.lower()), -np.inf))


def upper_float(x: arb) -> float:
    return float(np.nextafter(float(x.upper()), np.inf))


def checked_ceil(x: arb) -> int:
    """Return ceil(x) only when the whole ball has that same integer ceiling."""
    value = x.ceil().unique_fmpz()
    if value is None:
        raise ArithmeticError("Increase Arb precision to resolve a ceiling")
    return int(value)


def positive_count(a: arb, b: arb, q2: arb, delta: arb) -> arb:
    """The proved finite L2 barrier, using a>0 and weighted width b>0."""
    assert a > 0 and b > 0 and q2 > 0 and delta > 0
    return a**3 / (2 * ((b*q2).root(3) + (a*delta**2).root(3))**3)


def build_data(points: int) -> dict:
    one, pi = arb(1), arb.pi()
    sqrt2 = arb(2).sqrt()
    # Panel (a): rho=1_[0,1], A0=Omega=1, Q^2=pi, R=sqrt(2).
    cutoff_constant = 2 + sqrt2
    b_scalar_coefficient = 4 * (1 + sqrt2)
    a_scalar_coefficient = 1 + 2*cutoff_constant

    # Panel (b): A=lambda=tau=1, C=K_*(0)/A, exact closed forms.
    r = 3 - 2*sqrt2
    u = (-one).exp()
    c11 = (1-r*u*u)/(sqrt2*(1+r*u*u))
    c12 = (1-r)*u/(sqrt2*(1+r*u*u))
    c22 = 1-c11
    gap = ((c11-c22)**2 + 4*c12*c12).sqrt()
    eig_plus, eig_minus = (1+gap)/2, (1-gap)/2
    theta_plus = (2*c12/(c11-c22)).atan()/2
    theta_minus = theta_plus-pi/2
    assert c11 > arb(1)/2 and c11 < 1
    assert c12 > 0 and c11 > c22
    assert c11*c22-c12*c12 > 0 and eig_minus > 0
    assert (c11+c22-1).contains(0)
    assert (eig_plus+eig_minus-1).contains(0)
    # Exact diagonalization identities, evaluated with enclosing balls.
    c, s = theta_plus.cos(), theta_plus.sin()
    assert (c11*c+c12*s-eig_plus*c).contains(0)
    assert (c12*c+c22*s-eig_plus*s).contains(0)

    rows = []
    # Each displayed decimal is the exact input, not a hidden binary float.
    epsilons = [format(x, ".17g") for x in np.geomspace(1e-5, 1e-2, points)]
    epsilons[0], epsilons[-1] = "0.00001", "0.01"
    # Keep reference table inputs exactly decimal powers of ten as well.
    for index,value in enumerate(epsilons):
        for reference in ("0.0001", "0.001"):
            if abs(float(value)/float(reference)-1) < 1e-13:
                epsilons[index] = reference
    epsilons = sorted(set(epsilons).union({"0.0001", "0.001"}), key=float)
    previous = None
    for epsilon in epsilons:
        eps = arb(epsilon)
        assert eps > 0 and eps <= arb("0.5")
        a_scalar = 1-a_scalar_coefficient*eps
        assert a_scalar > 0
        scalar_lower = positive_count(a_scalar, b_scalar_coefficient*eps, pi, eps)
        scalar_upper_unrounded = 2/(pi*eps)*(2/eps).log()
        scalar_lower_count = checked_ceil(scalar_lower)
        scalar_upper_count = checked_ceil(scalar_upper_unrounded)
        assert scalar_lower_count <= scalar_upper_count

        # S9: eta=sqrt(epsilon) is prescribed, not optimized. For this
        # normalized example A1=c11 exactly and ||k11||_2^2 <= 1 analytically.
        eta = eps.sqrt()
        broad_fraction = 1-(-2*eta).exp()
        a_matrix = c11-eps-8*eps/broad_fraction
        b_matrix = 8*eta*eps/broad_fraction
        assert a_matrix > 0
        matrix_lower = positive_count(a_matrix, b_matrix, one, eps)
        matrix_lower_count = checked_ceil(matrix_lower)

        # Verify the two explicit upper-construction error inequalities.
        G, Gamma = arb(scalar_upper_count), eps/2
        early_error = pi*pi/(48*G)+Gamma
        late_error = (-pi*G*Gamma).exp()+1/(pi*G)
        assert early_error < eps and late_error < eps

        row = dict(
            epsilon=epsilon,
            scalar_lower_count=scalar_lower_count,
            scalar_upper_count=scalar_upper_count,
            matrix_lower_count=matrix_lower_count,
            fixed_channel_exact_count=2,
            epsilon_times_scalar_lower_count=str(Decimal(epsilon)*scalar_lower_count),
            epsilon_times_scalar_upper_count=str(Decimal(epsilon)*scalar_upper_count),
            epsilon_times_matrix_lower_count=str(Decimal(epsilon)*matrix_lower_count),
            arb_unique_ceiling_status="pass",
            scalar_lower_formula_ball=str(scalar_lower),
            scalar_lower_formula_outward_low=lower_float(scalar_lower),
            scalar_upper_formula_ball=str(scalar_upper_unrounded),
            matrix_lower_formula_ball=str(matrix_lower),
            matrix_lower_formula_outward_low=lower_float(matrix_lower),
            matrix_retained_mass_lower_ball=str(a_matrix),
            matrix_weighted_width_upper_ball=str(b_matrix),
            matrix_eta_ball=str(eta),
            scalar_construction_early_error_upper=upper_float(early_error),
            scalar_construction_late_error_upper=upper_float(late_error),
        )
        if previous is not None:
            assert float(epsilon) > float(previous["epsilon"])
            for field in ("scalar_lower_count", "scalar_upper_count", "matrix_lower_count"):
                assert row[field] <= previous[field], (field, row, previous)
        previous = row
        rows.append(row)

    scalar_asymptotic = 1/(8*(1+sqrt2)*pi)
    matrix_asymptotic = c11**3/8  # uses the proved conservative q2 <= 1
    # The finite barriers lie below the stated asymptotic constants/epsilon.
    for row in rows:
        eps = arb(row["epsilon"])
        assert arb(row["scalar_lower_formula_ball"])*eps < scalar_asymptotic
        assert arb(row["matrix_lower_formula_ball"])*eps < matrix_asymptotic

    # Schematic orientation samples from the exact defining formulas. They
    # are not quadrature, fitted channel directions or empirical eigenvalues.
    orientation = []
    for fraction in np.linspace(0, 2, 201):
        v = pi*arb(format(fraction, ".17g"))
        angle = v.cos().atan()/pi
        orientation.append(dict(
            omega_tau_over_pi=format(fraction, ".17g"),
            rotating_bright_angle_over_pi=float(angle),
            fixed_first_angle_over_pi=float(theta_plus/pi),
            fixed_second_angle_over_pi=float(theta_minus/pi),
        ))

    return dict(
        purpose="Analytic necessary bounds and explicit sufficient constructions; no computed optimum",
        arithmetic="Arb ball arithmetic; exact decimal epsilon inputs; unique integer ceilings checked",
        precision_bits=ctx.prec,
        versions=dict(python=platform.python_version(), numpy=np.__version__,
                      matplotlib=matplotlib.__version__, python_flint=flint.__version__),
        scalar=dict(
            density="rho(omega)=1 for 0<=omega<=1, zero otherwise",
            target="sin(t)/t, with value 1 at t=0",
            A0="1", Omega="1", Q_squared="pi", R="sqrt(2)",
            C_R="2+sqrt(2)", b_coefficient="4*(1+sqrt(2))",
            a="1-(5+2*sqrt(2))*epsilon",
            lower="a^3 / (2*((4*(1+sqrt(2))*epsilon*pi)^(1/3)+(a*epsilon^2)^(1/3))^3)",
            lower_domain="0<epsilon<1/(5+2*sqrt(2))",
            upper="ceil(2/(pi*epsilon)*log(2/epsilon))",
            upper_domain="0<epsilon<=1/2",
            construction="W_j=1/G, omega_j=(j-1/2)/G, Gamma_j=epsilon/2",
            asymptotic_liminf_epsilon_G_ball=str(scalar_asymptotic)),
        matrix=dict(
            A="1", lambda_value="1", tau="1", relative_error="epsilon=delta/A",
            trace_kernel="exp(-abs(t)) for both targets",
            equal_time_matrix_C=[[str(c11),str(c12)],[str(c12),str(c22)]],
            fixed_eigenvalues=[str(eig_plus),str(eig_minus)],
            fixed_eigenangles_over_pi=[str(theta_plus/pi),str(theta_minus/pi)],
            rotating_density="rho0(omega)*u(omega)*u(omega)^T; u=(1,cos(omega))/sqrt(1+cos(omega)^2)",
            fixed_density="rho0(omega)*C; rho0=2/[pi*(1+omega^2)]",
            prescribed_eta="sqrt(epsilon)",
            A1_ball=str(c11), q_squared_upper="1",
            a="A1-epsilon-8*epsilon/(1-exp(-2*sqrt(epsilon)))",
            b="8*epsilon^(3/2)/(1-exp(-2*sqrt(epsilon)))",
            lower="a^3 / (2*((b*1)^(1/3)+(a*epsilon^2)^(1/3))^3), valid a>0",
            exact_comparison_realization="two rank-one residues c_l e_l e_l^T, center 0, width 1",
            asymptotic_liminf_epsilon_G_safe_ball=str(matrix_asymptotic),
            general_simple_safe_constant="1/64",
            error_norm="uniform operator norm; same bounds also valid for uniform Frobenius norm"),
        rows=rows, orientation=orientation,
        checks=dict(
            positive_equal_time_matrix=True,
            equal_time_trace_exactly_one=True,
            closed_form_eigenpair_residuals_enclose_zero=True,
            scalar_lower_not_above_constructive_upper=True,
            explicit_upper_error_inequalities=True,
            decreasing_counts_on_ordered_epsilon_grid=True,
            positive_mass_for_all_matrix_bounds=True,
            finite_bounds_below_asymptotic_constants=True,
            same_trace_and_equal_time="algebraic identities, not quadrature estimates"))


def write_data(data: dict, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory/"accuracy_barrier.json").write_text(json.dumps(data, indent=2)+"\n")
    fields = ["epsilon", "scalar_lower_count", "scalar_upper_count", "matrix_lower_count",
              "fixed_channel_exact_count", "epsilon_times_scalar_lower_count",
              "epsilon_times_scalar_upper_count", "epsilon_times_matrix_lower_count",
              "arb_unique_ceiling_status", "scalar_lower_formula_outward_low",
              "matrix_lower_formula_outward_low", "scalar_construction_early_error_upper",
              "scalar_construction_late_error_upper"]
    with (directory/"accuracy_barrier.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(data["rows"])
    with (directory/"accuracy_barrier_channels.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(data["orientation"][0]))
        writer.writeheader()
        writer.writerows(data["orientation"])


def draw(data: dict, stem: Path) -> None:
    blue, orange, grey = "#256B96", "#D27A2C", "#586775"
    ink, grid = "#25313A", "#E4E8EB"
    plt.rcParams.update({
        "font.family":"DejaVu Sans", "font.size":9,
        "mathtext.fontset":"dejavusans", "axes.labelsize":9,
        "axes.titlesize":10, "axes.labelcolor":ink, "text.color":ink,
        "xtick.color":ink, "ytick.color":ink, "xtick.labelsize":8,
        "ytick.labelsize":8, "axes.linewidth":0.7,
        "axes.edgecolor":"#68747D", "lines.linewidth":1.7,
        "legend.fontsize":7.5, "pdf.fonttype":42, "ps.fonttype":42,
    })
    fig, axes = plt.subplots(1,2,figsize=(7.1,3.9))
    fig.subplots_adjust(left=.082,right=.965,bottom=.255,top=.87,wspace=.31)
    rows = data["rows"]
    eps = np.array([float(row["epsilon"]) for row in rows])
    left,right = axes
    # Conservative steps between tabulated values: decreasing lower bounds
    # use the right endpoint and decreasing upper bounds the left endpoint.
    left.step(eps,[row["scalar_upper_count"] for row in rows],where="post",
              color=orange,label="Explicit positive construction: upper bound")
    left.step(eps,[row["scalar_lower_count"] for row in rows],where="pre",
              color=blue,label="Positive Lorentzian class: lower bound")
    left.set_title("(a) Flat spectrum: all-time accuracy",loc="left",pad=11)
    left.set_ylabel(r"Scalar lines $G$")
    left.set_ylim(.8,1.5e6)
    left.text(.47,.93,r"$\gamma(t)=\sin t/t$",transform=left.transAxes,fontsize=9)
    left.text(.47,.84,r"$A_0=\Omega=1$, $Q^2=\pi$",transform=left.transAxes,fontsize=8)

    right.step(eps,[row["matrix_lower_count"] for row in rows],where="pre",
               color=blue,label="Rotating channel: lower bound")
    right.axhline(2,color=orange,lw=1.7,
                  label="Fixed channels: exact 2-line realization")
    right.set_title("(b) Same trace and equal-time matrix",loc="left",pad=11)
    right.set_ylabel(r"Scalar lines $G$")
    right.set_ylim(.8,1e4)
    right.text(.045,.33,r"$A=\lambda=\tau=1$",transform=right.transAxes,fontsize=8)
    right.text(.045,.24,r"$\mathrm{tr}\,K(t)=e^{-|t|}$",transform=right.transAxes,fontsize=8)

    inset = right.inset_axes([.53,.56,.44,.375])
    orientation = data["orientation"]
    v = np.array([float(row["omega_tau_over_pi"]) for row in orientation])
    angle = np.array([row["rotating_bright_angle_over_pi"] for row in orientation])
    inset.plot(v,angle,color=blue,lw=1.2)
    inset.axhline(orientation[0]["fixed_first_angle_over_pi"],color=orange,lw=.9,ls="--")
    inset.axhline(orientation[0]["fixed_second_angle_over_pi"],color=orange,lw=.9,ls="--")
    inset.set(xlim=(0,2),ylim=(-.5,.5),xticks=[0,1,2],yticks=[-.5,0,.5],
              xlabel=r"$\omega\tau/\pi$",ylabel=r"$\theta/\pi$")
    inset.set_title("Spectral directions",fontsize=7,pad=3)
    inset.tick_params(labelsize=6,length=2,pad=1)
    inset.xaxis.label.set_size(7);inset.yaxis.label.set_size(7)
    inset.xaxis.labelpad=1;inset.yaxis.labelpad=0
    for spine in inset.spines.values():spine.set_linewidth(.55)

    for ax in axes:
        ax.set_xscale("log");ax.set_yscale("log")
        ax.set_xlim(1e-5,1e-2)
        ax.set_xlabel(r"Relative all-time error $\varepsilon$",labelpad=4)
        ax.xaxis.set_major_locator(LogLocator(base=10,numticks=4))
        ax.yaxis.set_major_locator(LogLocator(base=10,numticks=8))
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.spines["top"].set_visible(False);ax.spines["right"].set_visible(False)
        ax.tick_params(direction="out",length=3,width=.65)
        ax.grid(which="major",axis="y",color=grid,lw=.55)
        ax.set_axisbelow(True)
        ax.legend(loc="upper left",bbox_to_anchor=(-.015,-.255),frameon=False,
                  handlelength=2.2,handletextpad=.65,borderaxespad=0,labelspacing=.6)
    stem.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(stem.with_suffix(".png"),dpi=400,facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"),facecolor="white",
                metadata={"CreationDate":None,"ModDate":None})
    plt.close(fig)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    parser.add_argument("--data-dir",type=Path,default=here/"data")
    parser.add_argument("--output-stem",type=Path,default=here/"outputs"/"figure3_accuracy_barrier")
    parser.add_argument("--points",type=int,default=241)
    parser.add_argument("--precision",type=int,default=128)
    args=parser.parse_args()
    if args.points<2 or args.precision<80:
        parser.error("Use at least 2 points and 80-bit arithmetic")
    ctx.prec=args.precision
    data=build_data(args.points)
    write_data(data,args.data_dir)
    draw(data,args.output_stem)
    print(f"Validated {len(data['rows'])} accuracy rows and all analytic invariants")
    print(args.output_stem.with_suffix(".png"))
    print(args.output_stem.with_suffix(".pdf"))


if __name__=="__main__":
    main()
