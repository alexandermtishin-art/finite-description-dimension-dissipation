"""Horizon bound for closed reductions with positive weights.

Lemma: M_T[gamma_G] >= gamma_G(0)^2/(2G) for gamma_G = sum_j W_j cos(w_j t), W_j > 0, any w_j, any T.
Theorem: |gamma_G - gamma| <= delta on [0,T]  =>  G >= (gamma(0)-delta)^2 / (2 (M_T[gamma]^(1/2) + delta)^2).
Asymptotically G >~ B_eff T/(2 pi), B_eff = (int rho)^2 / int rho^2.
Also: check of the lemma on the grouped kernels; dephasing fit of the projection error.
M_T here uses the 512-node kernel (T <= 31); the continuum kernel and the uniform grids are in dimension_dissipation.py.
Writes data/horizon_bound.json.
"""
import json, glob
import numpy as np
from scipy.integrate import quad
from scipy.optimize import curve_fit
from model import grid, m0, g, qf, D
from grpred import group

K = 8.0; M = m0 + g * qf
E = lambda k: np.hypot(k, M)
rho_k = lambda k: D * g * g * k**3 / (4 * np.pi**2 * E(k)**2)        # density per unit omega (omega = 2E)
dom = lambda k: 2 * k / E(k)
I1 = quad(lambda k: rho_k(k) * dom(k), 0, K, limit=400)[0]
I2 = quad(lambda k: rho_k(k)**2 * dom(k), 0, K, limit=400)[0]
Beff = I1**2 / I2
k, W = grid(K, 512); amp = W * g * g * k**2 / E(k)**3; om = 2 * E(k)
tau = np.linspace(0, 300, 60001)
gam = np.cos(np.outer(tau, om)) @ amp
g0 = gam[0]; delta = 0.1 * np.max(np.abs(gam[(tau > 1) & (tau <= 200)]))   # working tolerance (max over 1 < tau <= 200)


def MT(f, T):
    m = tau <= T; t = tau[m]
    return 2 * np.trapezoid((1 - t / T) * f[m]**2, t) / T


out = dict(gamma0=g0, gamma0_continuum=I1, int_rho2=I2, B_eff=Beff, slope=Beff / (2 * np.pi), delta=delta,
           saturation=(g0 - delta)**2 / (2 * delta**2), bound={}, TMT={}, lemma_check=[])
tauG = {int(a): b for a, b in json.load(open('data/tauG_GS.json')).items()}
for T in (1, 2, 3.43, 5, 7.09, 10, 14.93, 20, 30.92):
    Gl = (g0 - delta)**2 / (2 * (np.sqrt(MT(gam, T)) + delta)**2)
    Gm = min([G for G, t in tauG.items() if t >= T - 1e-9], default=None)
    out['bound'][str(T)] = dict(G_necessary=Gl, G_grouping=Gm)
for T in (10, 30):
    out['TMT'][str(T)] = T * MT(gam, T)
out['TMT_limit'] = np.pi * I2
for G in (8, 16, 32, 64, 128):
    kB, WB, _ = group(k, W, np.zeros((3, 512)), G); EB = E(kB); aB = WB * g * g * kB**2 / EB**3
    gG = np.cos(np.outer(tau, 2 * EB)) @ aB
    for T in (5.0, 50.0):
        out['lemma_check'].append(dict(G=G, T=T, MT=MT(gG, T), bound=gG[0]**2 / (2 * G), ok=bool(MT(gG, T) >= gG[0]**2 / (2 * G))))
# projection error vs age: dephasing form
Dd = [r for f in glob.glob('data/decomp_*.json') for r in json.load(open(f))]
x = np.array([K * r['t0'] / r['G'] for r in Dd]); y = np.array([r['proj_size'] for r in Dd])
fm = lambda x, A, c, b: np.sqrt(b**2 + A**2 * (1 - np.sinc(c * x / np.pi)**2))
p, _ = curve_fit(fm, x, y, p0=[0.07, 1.0, 0.01])
out['age_fit'] = dict(A=p[0], c=p[1], b=p[2], n=len(y), resid_rms=float(np.sqrt(np.mean((y - fm(x, *p))**2))), spread=float(np.std(y)),
                      explained=float(1 - np.mean((y - fm(x, *p))**2) / np.var(y)))
print(json.dumps(out, indent=1, default=float))
json.dump(out, open('data/horizon_bound.json', 'w'), indent=1, default=float)
