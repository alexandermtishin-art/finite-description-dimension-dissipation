import numpy as np
from scipy.integrate import solve_ivp
from model import *
qi,Tp,tau_r=0.2,10.0,0.5
c=np.array([462,-1980,3465,-3080,1386,-252]); pw=np.arange(6,12)
f =lambda x: np.sum(c*x**pw)
fp=lambda x: np.sum(c*pw*x**(pw-1))
def qpath(t,vs):
    x=t/Tp; return qi+(qf-qi)*f(x)+vs*Tp*(x-1)*f(x)
def run(N,vs,K=8.0,T=100.0,ret_sol=False):
    k,W=grid(K,N); Z=Zbare(K)
    def modes_rhs(t,y):
        q=qpath(t,vs); M=m0+g*q; s=y.reshape(3,N)
        return (2*np.stack([-M*s[1],M*s[0]-k*s[2],k*s[1]])).ravel()
    M0=m0+g*qi; E0=np.hypot(k,M0); s0=np.stack([-k/E0,0*k,-M0/E0])
    sp=solve_ivp(modes_rhs,(0,Tp),s0.ravel(),method='DOP853',rtol=1e-10,atol=1e-12).y[:,-1]
    y=np.concatenate([[qf,vs],sp])
    def full(t,y,ramp):
        q,v=y[0],y[1]; s=y[2:].reshape(3,N); M=m0+g*q; E=np.hypot(k,M)
        F=g*np.sum(W*(s[2]+M/E)); a=(-(Vp(q)+F)/Z)*(f(min(t/tau_r,1.0)) if ramp else 1.0)
        return np.concatenate([[v,a],(2*np.stack([-M*s[1],M*s[0]-k*s[2],k*s[1]])).ravel()])
    y=solve_ivp(lambda t,y:full(t,y,True),(0,tau_r),y,method='DOP853',rtol=1e-10,atol=1e-12).y[:,-1]
    sol=solve_ivp(lambda t,y:full(t,y,False),(0,T),y,method='DOP853',rtol=1e-10,atol=1e-12,dense_output=True)
    if ret_sol: return sol,k,W,Z
    return approaches(sol,k,W,Z,T)
def approaches(sol,k,W,Z,T):
    tt=np.linspace(0,T,int(T*400)+1); Y=sol.sol(tt); q,v=Y[0],Y[1]
    res=[]; i=1
    while i<len(tt)-1:
        if v[i-1]>0 and v[i]<=0 and q[i]>qb:
            Ephi=Z*v[i]**2/2+V(q[i])-V(qt)
            j=i+1; out=None
            while j<len(tt):
                if q[j-1]>qb and q[j]<=qb: out='C';break
                if v[j-1]<0 and v[j]>=0: out='R';break
                j+=1
            if out is None: break
            if Ephi>V(qb)-V(qt): res.append((round(tt[i],3),out,round(Ephi-(V(qb)-V(qt)),6)))
            i=j
        i+=1
    return res
