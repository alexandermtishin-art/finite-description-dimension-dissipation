"""Constants quoted in Sections 6 and 9.1 for the scalar-precession kernel.

c_-(delta) of Eq. (23) and c_+; N(T*,delta) and the uniform-grid count at T*; the crossover of the uniform-grid and random-grid counts with theta optimised;
the explicit bound of the first part of Theorem 3 on T_rec(1093, delta) with tau_1 = V/eta (optimised over eta and k);
Fejer entries of Table 1 at the uniform-grid horizons. Uses data/gam_continuum.npy. Writes data/p1_constants.json.
"""
import json
from math import e, log, log1p, exp, pi, sqrt
import numpy as np

g0, d, a, b, V = 9.647, 0.20204585081276935, 0.452, 16.006, 2.43
tau, gam = np.load('data/gam_continuum.npy')
g0c = float(gam[0])
c1 = pi / 3 + pi**2 / 6
out = {}
out['c_minus'] = ((g0 - d)**2 - 2 * e * d * d) / (2 * e * d * d * log((g0 + d) / d))
out['c_plus'] = 2 * g0**2 / d**2
out['c_gauss_heuristic'] = g0**2 / d**2
out['dirichlet_Q8'] = 1 / log(8)
out['condition_gamma0_over_delta'] = g0 / d
out['condition_needed'] = 1 + 2 * sqrt(e)


def MT(T):
    m = tau <= T; t = tau[m]
    return 2 * np.trapezoid((1 - t / T) * gam[m]**2, t) / T


def N(T):
    return (g0c - d)**2 / (2 * (np.sqrt(MT(T)) + d)**2)


Tstar = pi * 7.840 / d**2
out['T_star'] = Tstar
out['N_Tstar'] = float(N(Tstar))
out['eq9_Tstar'] = (b - a) / (2 * pi) * (Tstar + V / (d - c1 * V / Tstar))
out['fejer_table1'] = {str(T): float(N(T)) for T in (3.22, 8.73, 21.08, 46.41, 97.83)}


def G12(T):
    return min((2 * g0**2 / ((1 - t)**2 * d**2)) * log(2 * g0 * b * T / (t * d) + 4) for t in np.linspace(0.005, 0.9, 900))


def G9(T):
    return (b - a) / (2 * pi) * (T + V / (d - c1 * V / T))


lo, hi = 1e3, 1e6
for _ in range(80):
    m = (lo * hi)**0.5
    if G12(m) < G9(m): hi = m
    else: lo = m
out['crossover_eq12_eq9'] = hi


def lnTrec_upper(G):
    best, arg = np.inf, None
    Ap, Am = g0 + d, g0 - d
    for eta in np.geomspace(0.002, 1.0, 600):
        x = d + eta; tau1 = V / eta
        for k in range(1, min(G, 400) + 1):
            q = Am**2 * k * (G - k + 1) / (e * G * G * x * x)
            if q <= 1:
                continue
            kl = k * log(q)
            val = log(2 * tau1) + 2 * k * log(Ap / x) - (kl + log1p(-exp(-kl)))
            if val < best:
                best, arg = val, dict(eta=float(eta), k=k)
    return best, arg


best, arg = lnTrec_upper(1093)
out['Trec_1093_upper'] = exp(best); out['Trec_1093_args'] = arg
print(json.dumps(out, indent=1))
json.dump(out, open('data/p1_constants.json', 'w'), indent=1)
