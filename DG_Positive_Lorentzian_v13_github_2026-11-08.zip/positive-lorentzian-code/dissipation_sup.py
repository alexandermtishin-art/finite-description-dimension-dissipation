"""Supremum form of the dissipation bound (Theorem 6, Eq. (27)) and refined common damping rates."""
import numpy as np, json
from scipy.integrate import quad
from model import m0,g,qf,D
import os
K0=8.0; M0=m0+g*qf; a0,b0=2*abs(M0),2*np.hypot(K0,M0)
def _rho(w):
    k=np.sqrt(max((w/2)**2-M0**2,0)); return D*g*g*k**3/(np.pi**2*w**2)
if os.path.exists('data/gam_continuum.npy'):
    tau,gam=np.load('data/gam_continuum.npy')
else:                                           # continuum kernel by QAWO quadrature, step 0.05 up to 1200
    tau=np.arange(0,1200.0001,0.05)
    gam=np.array([quad(_rho,a0,b0,weight='cos',wvar=t,limit=400)[0] if t>0 else quad(_rho,a0,b0)[0] for t in tau])
    np.save('data/gam_continuum.npy',np.vstack([tau,gam]))
d=0.20204585081276935; g0=gam[0]
Ts=np.arange(5,1200.01,5.0)
c=np.cumsum(np.r_[0,(gam[1:]**2+gam[:-1]**2)/2*np.diff(tau)]); c2=np.cumsum(np.r_[0,((tau[1:]*gam[1:]**2)+(tau[:-1]*gam[:-1]**2))/2*np.diff(tau)])
def MT(T):
    i=np.searchsorted(tau,T); return 2*(c[i]-c2[i]/T)/T
N=np.array([(g0-d)**2/(2*(np.sqrt(MT(T))+d)**2) for T in Ts])
out={}
for G in (1,16,64,128,192,256):
    v=(N-G)/Ts; i=np.argmax(v); out[G]=(float(v[i]),float(Ts[i]))
print('sup',out)
K=8.0;M=m0+g*qf;wmin,wmax=2*abs(M),2*np.hypot(K,M)
def rho(w):
    k=np.sqrt(max((w/2)**2-M**2,0)); return D*g*g*k**3/(np.pi**2*w**2)
ref={}
for G,G0 in ((128,0.075),(192,0.05),(256,0.0375)):
    e=np.linspace(wmin,wmax,G+1); m=(e[:-1]+e[1:])/2; W=np.array([quad(rho,a,b)[0] for a,b in zip(e[:-1],e[1:])])
    C=np.cos(np.outer(tau,m))*W; best=None
    for Gm in np.arange(G0-0.0025,G0+0.00001,0.0001):
        if np.max(np.abs((C*np.exp(-Gm*tau)[:,None]).sum(1)-gam))<=d: best=Gm; break
    ref[G]=(round(best,4),round(G*best,2))
print('refined',ref)
json.dump(dict(sup=out,refined=ref),open('data/dissipation_sup.json','w'),indent=1)
