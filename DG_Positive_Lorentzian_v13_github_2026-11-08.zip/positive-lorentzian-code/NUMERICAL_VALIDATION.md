# Numerical validation

## Figure 3 and the accuracy barriers

Figure 3 evaluates proved finite-error inequalities, rather than fitting or
sampling a new kernel. `accuracy_barrier.py` uses Arb ball arithmetic and
accepts each plotted ceiling only if uniquely resolved. The exact inputs,
checks and versions are in `data/accuracy_barrier.json`; see
`ACCURACY_BARRIER.md` and Supplement S10. The sections below give the
validation status of the scalar-model calculations.

## Damped constructions and rank bounds

The three damped constructions are checked by interval arithmetic
over all real times. They are not merely values on a denser time grid.
`certify_damped.py` is the executable certificate. It uses 128-bit Arb
arithmetic through python-flint 0.9.0. A double-precision planning pass chooses
a subdivision; the proof subsequently checks every chosen interval again in
Arb and does not use the floating planning values as evidence.

## Exact model and constructions

The positive minimum q is the unique root of q^3-q+1/20 on [0.9,1]. Rational
bisection encloses that root; its derivative is positive on the whole bracket.
The mass is M=q-6/5 and m=-M>0. Thus the certificate refers to the exact model
specified in the paper rather than a rounded value M=-0.226. The ordinary
scripts use a double-precision approximation to the same algebraic root;
the certificate recomputes the exact-model frequencies and cell weights.

The kernel in the momentum variable is

    gamma(t) = C integral_0^K k^4 (k^2+m^2)^(-3/2)
                         cos(2 sqrt(k^2+m^2) t) dk,
    C=3/pi^2, K=8.

Its spectral support is [2m,2 sqrt(K^2+m^2)]. The G frequency cells have exactly
equal widths on this band, midpoint frequencies, and weights equal to the exact
integrals of rho over those cells. Those weights are evaluated in Arb using
the primitive

    C [k sqrt(k^2+m^2)/2 + m^2 k/sqrt(k^2+m^2)
                               -3 m^2 asinh(k/m)/2].

The linewidths are the exact decimal numbers 0.07280390625, 0.049658984375,
and 0.0374 for G=128,192,256. The accuracy is the exact decimal
delta=0.20204585081276935.

## Rigorous quadrature remainder

An Arb Gauss-Legendre rule with N=768 nodes is applied in k, not omega. On the
Bernstein ellipse for [0,K] with parameter r=5/4 the semiaxes are
A=K(r+r^-1)/4=4.1 and B=K(r-r^-1)/4=0.9. The two singularities k=+/- i m are
outside the ellipse because L=sqrt((K/(2A))^2+(m/B)^2)>1. Their Euclidean
distance from the ellipse is at least d=B(L-1). The principal square root is
analytic inside it: where Re k=0, the ellipse has |Im k|<m, so k^2+m^2 does
not meet the negative real axis.

For 0<=t<=110, the integrand is bounded on that ellipse by

    H=C (K/2+A)^4 d^-3 exp(2*110*B).

Here |Im sqrt(k^2+m^2)|<=|Im k|. Truncating its Chebyshev series at degree
2N-1 has uniform error <=2 H r^(-2N)/(1-r^-1). Gauss exactness for that
polynomial and positivity of its weights give the integration-error bound

    epsilon_Q <= 4 K H r^(-2N)/(1-r^-1).

Arb verifies epsilon_Q<9.67e-52. Node/weight computation, evaluation and sums
are also enclosed by Arb. The mathematical kernel error therefore includes
both the analytic remainder and roundoff.

## Rigorous control between time nodes

For f(t)=gamma_G(t)-gamma(t), a time interval [l,r] of width h satisfies

    sup_[l,r] |f| <= max(|f(l)|,|f(r)|) + h^2 sup_[l,r]|f''|/8.

The second derivative is bounded by

    integral rho(omega) omega^2 d omega
      + exp(-Gamma*l) sum_j W_j (omega_j^2+Gamma^2).

The first integral is evaluated by the exact primitive identity

    C/2 [K E (2 K^2-3 m^2)+3 m^4 asinh(K/m)], E=sqrt(K^2+m^2).

The construction uses common Gamma in each example. The certificate checks
4857 intervals covering exactly [0,110], with endpoints stored internally as
rational numbers. The largest checked upper bounds are approximately
0.201750725225, 0.201400573874 and 0.202017850021, respectively; all are
strictly below delta. Decimal summaries in JSON are rounded outward.

## Infinite-time tail

The density is monotone on its band, so the variation of its zero extension
is V=2 rho(b)=2.4297692028305273... . Integration by parts gives
|gamma(t)|<=V/t. Positivity of the finite weights gives

    |gamma_G(t)-gamma(t)| <= gamma(0) exp(-Gamma*t)+V/t.

This is decreasing for t>=110 and is below delta there for each example.
The finite-interval and tail inequalities together prove all-time accuracy.

## Certified continuum rank bounds

`certify_rank.py` uses a positive Galerkin compression rather than treating
sampled Nyström eigenvalues as exact. Its orthonormal basis consists of the
normalized indicators of n equal cells of width h=T/n. The Toeplitz entries
of the exact compressed operator are

    A_ij=h integral rho(omega) sinc(omega*h/2)^2
                                      cos(omega*(i-j)*h) d omega.

They are enclosed by the same Arb quadrature and analytic ellipse argument;
the extra sinc-squared factor contributes at most exp(2hB) on the ellipse.
The eigenvalues of this compression are no greater than the corresponding
eigenvalues of the positive continuum operator. A lower bound on a spectral
tail of the compression is therefore a valid lower bound on the continuum
tail in the paper's rank theorem.

All approximate eigenvalues are enclosed by an Arb residual calculation.
Let Q and Lambda be the exact dyadic matrices obtained from a numerical
symmetric eigensolver, eta=||Q^T Q-I||_F<1, s=sqrt(1-eta), and
d=eta/(1+s). For the polar factor U of Q, ||Q-U||_2<=d. From
R=AQ-Q Lambda one obtains

    ||A-U Lambda U^T||_2
        <= (||R||_F+2d ||Lambda||_2)/s.

Every quantity on the right is evaluated with Arb; Weyl's inequality then
encloses the ordered eigenvalues. The resulting lower eigenvalue bounds are
squared and summed in Arb to exclude insufficient ranks. No unverified
eigensolver rounding-error estimate is used.

The Nyström values and the horizon scans are numerical
approximations. Only the examples and rows explicitly recorded in
`damped_certificates.json`, `rank_certificates.json` and
`rank_certificates_all.json` are certified. The full run certifies the same
integer mode lower bounds as the Nyström evaluation for all nine model rows at all three
accuracies. At T=97.83 and the working accuracy, the Galerkin bound before
integer rounding is 112.5 and the Nyström estimate is 113; both imply
the rigorous integer requirement G>=113. Other displayed half-integer
values are recovered exactly.

## Environment

- NumPy 2.0 or later is required because numpy.trapezoid is used.
- Python-flint 0.9 or later is required for the certificate APIs.
- The rank-tail routine includes the empty tail after full rank.
- Coarse damping scans in `data/` are exploratory; the refined scans and the
  interval certificates are stored in separate files.

The certificate dependencies are not vendored; install them using requirements.txt.

The recorded run used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and
python-flint 0.9.0. The double-precision eigensolver is a source of approximate
eigenvectors only; Arb verifies its residual rather than trusting those
versions to supply rigorous eigenvalues.
