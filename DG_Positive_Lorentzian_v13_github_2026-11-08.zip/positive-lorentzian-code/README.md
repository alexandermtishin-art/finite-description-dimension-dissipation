# Accuracy barriers for positive Lorentzian bath representations: code and data

Code, stored data and interval certificates for the article
"Accuracy barriers for positive Lorentzian bath representations" by A. M. Tishin.
Section, equation, table and figure numbers below refer to the main text (MAIN)
and its Supplementary Material (Supplement).

## Requirements

Python 3.10 or later and the packages in `requirements.txt`:

```bash
python -m pip install -r requirements.txt
```

NumPy 2.0 or later is required (`numpy.trapezoid`). Python-flint 0.9 or later
supplies Arb ball arithmetic for the certificates. Run all commands from this
folder. Results are written to `data/`, figures and logs to `outputs/`.

## Status of the numbers

Three kinds of results are kept apart throughout.

- **Proved bounds evaluated with interval arithmetic:** the finite-error forms
  of Theorems 1 and 2 (Figure 3, Supplement S10), the all-time error bounds of
  the damped constructions (Table 2) and the spectral-tail integer lower bounds
  (Table 1). Outputs: `data/accuracy_barrier.json`, `data/damped_certificates.json`,
  `data/rank_certificates.json`, `data/rank_certificates_all.json`.
- **Numerical evaluations of analytic expressions:** rate functions, Fejér
  counts, Nyström spectral tails and the refined leakage coefficient.
- **Sampled computations:** first crossings of explicit constructions and the
  random-grid runs. These are finite-size observations, not certified suprema.

`NUMERICAL_VALIDATION.md` gives the error bounds behind every certificate and
`ACCURACY_BARRIER.md` the formulas behind Figure 3.

## Scripts and where they are used

| Script | What it computes | MAIN / Supplement |
|---|---|---|
| `accuracy_barrier.py` | Finite-error bounds of Theorem 1, Corollary 1, the flat-band construction (9) and Theorem 2; Arb-validated integer counts; Figure 3 | Sections 3, 4, 9.3; S8–S10 |
| `leakage_refined.py` | Exact small-width leakage of a trapezoid-weighted Cauchy line and the effective coefficient 6.41 Ω (R = √2 Ω), 6.14 Ω (R = 1.8 Ω) | Remark after Theorem 1; S8 |
| `phase_rates.py` | Rate function I(r), 60-digit crosscheck, exact phase-moment coefficients (28), signed finite-rank obstruction (20) | Sections 6–7; S1–S3 |
| `p1_constants.py` | c₋(δ) of Eq. (23), Fejér entries of Table 1 for the scalar model | Sections 6, 9.1 |
| `certify_damped.py` | All-time interval certificates of the three damped constructions | Table 2, Section 9.1; S7 |
| `certify_rank.py` | Spectral-tail lower bounds from validated Galerkin compressions (`--all` for all nine horizons and three accuracies) | Table 1, Eq. (30); S7 |
| `matrix_example.py` | Analytic two-channel kernels and first crossings at equal oscillator count | Theorem 8, Section 9.2; S5 |
| `figure_matrix.py` | Figure 2 from the stored matrix data | Figure 2; S5 |
| `model.py`, `prot.py`, `grpred.py` | Scalar precession model (36), momentum quadrature, collective (block) grouping | Section 9.1; S7 |
| `dimension_dissipation.py` | Continuum kernel, Fejér count N(T, δ) of Eq. (26), uniform and damped grids | Section 7, Table 1, Figure 1a |
| `rank_bound.py` | Nyström spectral-tail curves and counts, flat and Drude spectra | Figure 1a; S7 |
| `dissipation_sup.py` | Second-moment linewidth bound (27) and common damping rates | Sections 7, 9.1 |
| `horizon_bound.py`, `tauG_all.py` | Fejér bound and horizons of the block constructions | Figure 1a; S7 |
| `refine_horizons.py` | Uniform-grid first crossings and common damping scans | Tables 1–2 |
| `long_horizon.py` | Uniform and random grids for the flat spectrum | Figure 1b, Section 9.2 |
| `table2_fine.py` | Discretization comparisons and the random damped flat-spectrum example | Table S2, Section 9.2 |
| `p1_figure.py` | Figure 1 from the stored data | Figure 1 |

## Commands

Central bounds and certificates:

```bash
python accuracy_barrier.py
python leakage_refined.py
python certify_damped.py
python certify_rank.py
python certify_rank.py --all
```

Rates, matrix example and figures:

```bash
python phase_rates.py
python matrix_example.py
python figure_matrix.py
```

Scalar-model computations:

```bash
python dimension_dissipation.py
python rank_bound.py
python dissipation_sup.py
python horizon_bound.py
python long_horizon.py
python table2_fine.py
python refine_horizons.py
python tauG_all.py
python p1_constants.py
python p1_figure.py
```

`dissipation_sup.py` reads `data/gam_continuum.npy` and computes it if absent.
The interval computations take longer than the other scripts.

## File integrity

`SHA256SUMS` lists every file except itself. Verify with

```bash
sha256sum -c SHA256SUMS
```

Regenerating an output can change its checksum, including PDF metadata.

## License

MIT, see `LICENSE`.
