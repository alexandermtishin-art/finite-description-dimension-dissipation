# Figure 3: analytic bounds at refined accuracy

`accuracy_barrier.py` creates `outputs/figure3_accuracy_barrier.png` (400 dpi),
the corresponding vector PDF, and three machine-readable data files. It does
not fit a kernel or solve a mode-count optimization problem. Both panels use
finite-error inequalities; neither replaces an asymptotic limit by a
finite-error claim. The old figures are unchanged.

Install the code packet's requirements, then run from any working directory:

```sh
python accuracy_barrier.py
```

The script requires Python, NumPy, Matplotlib and python-flint (0.9.0 used for
the supplied data). It uses 128-bit Arb ball arithmetic by default. The exact
decimal input epsilon, enclosing balls, parameter formulas, checks and library
versions are recorded in `data/accuracy_barrier.json`. The CSV contains the
counts and conservative floating summaries; all plotted integer ceilings
were resolved to a unique integer by Arb. Increase precision if an alternative
grid happens to put a ball across an integer threshold.

## Panel (a): a necessary count and a sufficient construction

The target is the flat spectrum `rho = 1_[0,1]`, with

\[
\gamma(t)=\frac{\sin t}{t},\qquad A_0=\Omega=1,
\qquad Q^2=\|\gamma\|_{L^2(\mathbb R)}^2=\pi.
\]

The relative error equals the absolute error, \(\varepsilon=\delta\). The
improved spectral-test theorem in Supplement S8 is evaluated at
\(R=\sqrt2\Omega\), so that

\[
C_R=2+\sqrt2,\quad \beta=4(1+\sqrt2),\quad
a=1-(5+2\sqrt2)\varepsilon.
\]

For \(0<\varepsilon<1/(5+2\sqrt2)\), every positive independent-Lorentzian
description with all-time uniform error at most \(\varepsilon\) must have

\[
G\ge L_{\rm sc}(\varepsilon):=
\frac{a^3}{2\left[(\beta\pi\varepsilon)^{1/3}
 +(a\varepsilon^2)^{1/3}\right]^3}.
\]

The blue curve is the necessary integer count \(\lceil L_{\rm sc}\rceil\).
The orange curve is the count of a proved sufficient construction,

\[
U_{\rm sc}(\varepsilon)=
\left\lceil\frac{2}{\pi\varepsilon}\log\frac2\varepsilon\right\rceil,
\quad W_j=\frac1G,\quad \omega_j=\frac{j-1/2}{G},
\quad \Gamma_j=\frac\varepsilon2,
\]

valid for \(0<\varepsilon\le1/2\). Both the short-time bound
\(\pi^2/(48G)+\varepsilon/2<\varepsilon\) and the long-time bound
\(e^{-\pi G\varepsilon/2}+1/(\pi G)<\varepsilon\) are rechecked with Arb
at every plotted accuracy. The lower and upper curves do not assert a
computed optimum or a sharp constant. Their asymptotic rates leave one
logarithm between them.

## Panel (b): equal trace and equal-time matrix

Take \(A=\lambda=\tau=1\),

\[
s(\omega)=\frac2{\pi(1+\omega^2)},\qquad
u(\omega)=\frac{(1,\cos\omega)^{\mathsf T}}{\sqrt{1+\cos^2\omega}},
\quad R_*(\omega)=s(\omega)u(\omega)u(\omega)^{\mathsf T}.
\]

Put \(C=K_*(0)\) and \(R_{\rm fix}(\omega)=s(\omega)C\). These two
targets obey exactly

\[
\operatorname{tr}K_*(t)=\operatorname{tr}K_{\rm fix}(t)=e^{-|t|},
\qquad K_*(0)=K_{\rm fix}(0)=C.
\]

No frequency quadrature is used to determine \(C\). With
\(r=3-2\sqrt2\) and \(v=e^{-1}\), its exact entries are

\[
C_{11}=\frac{1-rv^2}{\sqrt2(1+rv^2)},\qquad
C_{12}=\frac{(1-r)v}{\sqrt2(1+rv^2)},\qquad C_{22}=1-C_{11}.
\]

The fixed-channel target has an exact two-line representation: diagonalize
\(C=\sum_{\ell=1}^2c_\ell e_\ell e_\ell^{\mathsf T}\), and use residues
\(c_\ell e_\ell e_\ell^{\mathsf T}\), width one and center zero. The orange
line displays this exact realization count, without asserting finite-error
optimality.

For the rotating target the blue curve uses the finite-error theorem in
Supplement S9 with the operator-norm constant \(C_{\rm op}=4\). It is also
safe for uniform Frobenius error. The choice
\(\eta=\sqrt\varepsilon\) is prescribed and is not numerically optimized.
The exact mass is \(A_1=C_{11}\); the proved analytic estimate
\(\|K_{*,11}\|_2^2\le1\) is used. Therefore, whenever \(a_m>0\),

\[
a_m=C_{11}-\varepsilon-
\frac{8\varepsilon}{1-e^{-2\sqrt\varepsilon}},\qquad
b_m=\frac{8\varepsilon^{3/2}}{1-e^{-2\sqrt\varepsilon}},
\]

\[
G\ge L_{\rm mat}(\varepsilon):=
\frac{a_m^3}{2\left[b_m^{1/3}
 +(a_m\varepsilon^2)^{1/3}\right]^3}.
\]

All 241 plotted errors lie in the valid domain \(a_m>0\). The blue curve
shows \(\lceil L_{\rm mat}\rceil\), not a construction for the rotating
target. The inset gives the exact rotating bright direction
\(\theta_*(\omega)=\arctan(\cos\omega)\) (blue), and the two fixed
eigendirections of \(C\) (orange dashed). Eigenvalues, eigenangles and
orientation samples are in the JSON and `accuracy_barrier_channels.csv`.

## Validation and reproduction

The checks concern the quantities that support the figure: valid bound
domains, positivity and trace of \(C\), zero enclosed eigenpair residuals,
the two constructive error inequalities, unique integer ceilings and
ordering of the lower and upper scalar bounds. No sampling-based kernel
error certificate or empirical fit is substituted for a theorem.

The supplied grid covers \(10^{-5}\le\varepsilon\le10^{-2}\). Necessary
counts decrease with epsilon: their positive retained-mass bound decreases,
while their weighted-width bound and epsilon increase. For the matrix
choice this follows from monotonicity of
\(x^2/(1-e^{-2x})\) and \(x^3/(1-e^{-2x})\), \(x=\sqrt\varepsilon>0\).
The constructive upper count decreases as well. To preserve the respective
inequalities between displayed grid points, the step plots use the next
grid point for each lower bound and the preceding point for the upper bound.

The complete script was rerun to a separate temporary directory. JSON,
both CSV files, PNG and PDF reproduced byte for byte in the recorded
environment.

Suggested caption:

**Figure 3. Accuracy bounds for positive independent Lorentzian
descriptions.** (a) For the flat spectrum, the analytic necessary count
(blue) and a proved positive midpoint construction count (orange) bracket
the minimum all-time mode count. (b) Two matrix baths have the same trace
correlation at every time and the same equal-time matrix. The rotating
target obeys the finite-error necessary count shown in blue; the fixed
comparison bath has the exact two-line realization shown in orange. The
inset compares its fixed eigendirections with the target's rotating bright
direction. All necessary counts are rounded up. Curves are analytic bounds
and explicit realization counts; no numerical optimum is reported.
